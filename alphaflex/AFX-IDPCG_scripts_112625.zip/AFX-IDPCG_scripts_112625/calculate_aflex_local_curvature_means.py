"""
Compute local backbone curvature (κ) along the Cα trace for PDB files, including
multi-model ensembles, across the entire protein chain (no IDR input required).
Exports per-residue and per-chain summaries. Optionally process all models.

Curvature definition (discrete):
    κ_i = 2*sin(θ_i/2) / |r_{i+1} - r_{i-1}|
where θ_i is the angle between vectors (r_i - r_{i-1}) and (r_{i+1} - r_i).

Key features:
- Handles chain breaks (missing residues / big CA-CA jumps)
- Multi-model support (process first model or all models)
- Exports per-residue and per-chain CSVs
- Units selectable: Å^-1 (default) or nm^-1

Assumptions:
- PDB filename stem equals UniProt ID (e.g., Q5VUM1.pdb -> "Q5VUM1").

Usage:
    python compute_curvature.py \
            --pdb-dir ./pdbs \
            --chain-id A \
            --model-mode all \
            --units A-1 \
            --outdir ./curvature_out \
            --n-proc 8
"""
import os
import argparse
from glob import glob
from typing import List, Tuple, Optional

import numpy as np
import pandas as pd
from Bio.PDB import PDBParser

# ------------------------------ Helpers ------------------------------

def stem_as_uniprot_id(pdb_path: str) -> str:
    return os.path.splitext(os.path.basename(pdb_path))[0]

# (Removed IDR JSON handling; full-chain analysis only.)

def safe_acos(x: float) -> float:
    return np.arccos(np.clip(x, -1.0, 1.0))

def detect_chain_breaks(coords: np.ndarray,
                        resseq: List[int],
                        icode: List[str],
                        ca_ca_max: float = 4.5) -> np.ndarray:
    """
    Return a boolean mask 'is_break' of length N marking positions i where a break exists
    BETWEEN i and i+1. Criteria:
      - CA-CA distance > ca_ca_max Å
      - or PDB numbering not consecutive (resseq jumps by >1 ignoring icode)
    """
    N = len(coords)
    is_break = np.zeros(N-1, dtype=bool)
    for i in range(N-1):
        d = np.linalg.norm(coords[i+1] - coords[i])
        if d > ca_ca_max:
            is_break[i] = True
            continue
        # numbering check: tolerate insertion codes; require resseq[i+1] == resseq[i] + 1
        if (resseq[i+1] - resseq[i]) != 1:
            is_break[i] = True
    return is_break

def compute_curvature_from_ca(coords: np.ndarray,
                              break_mask: np.ndarray) -> np.ndarray:
    """
    Compute curvature κ_i at internal residues i=1..N-2.
    For termini and around breaks, returns NaN.
    """
    N = len(coords)
    kappa = np.full(N, np.nan, dtype=float)
    if N < 3:
        return kappa

    # Can't compute across breaks: if a break at i-1 or i → kappa[i] invalid
    for i in range(1, N-1):
        if break_mask[i-1] or break_mask[i]:
            continue
        v1 = coords[i]   - coords[i-1]
        v2 = coords[i+1] - coords[i]
        n1 = np.linalg.norm(v1)
        n2 = np.linalg.norm(v2)
        if n1 == 0.0 or n2 == 0.0:
            continue
        cos_th = float(np.dot(v1, v2) / (n1 * n2))
        theta = safe_acos(cos_th)
        chord = np.linalg.norm(coords[i+1] - coords[i-1])
        if chord == 0.0:
            continue
        kappa[i] = 2.0 * np.sin(theta / 2.0) / chord

    return kappa

def nm_scale_factor(units: str) -> float:
    """
    Convert Å^-1 to requested units. κ computed in Å^-1 by default.
    If units == 'nm-1', multiply by 10.0 (since 1 Å = 0.1 nm → Å^-1 = 10 * nm^-1).
    If units == 'A-1', factor = 1.0.
    """
    u = units.strip().lower()
    if u in ("a-1", "å^-1", "ang^-1", "angstrom^-1"):
        return 1.0
    elif u in ("nm-1", "nanometer^-1"):
        return 10.0
    else:
        raise ValueError(f"Unsupported units: {units}. Use 'A-1' or 'nm-1'.")

# (Removed IDR mask utilities; full-chain analysis only.)

def residue_table_from_chain(chain) -> pd.DataFrame:
    """
    Extract residue-level table for a Biopython Chain object:
      seq_index: 1..N by CA order
      resseq, icode
      CA coordinates (x,y,z)
    Excludes residues lacking a CA atom.
    """
    rows = []
    for res in chain.get_residues():
        het, resseq, icode = res.get_id()  # (' ', 42, ' ') for standard residues
        # skip HETATM and waters
        if het.strip() not in ("", "W"):
            continue
        if "CA" not in res:
            continue
        ca = res["CA"].get_coord()
        rows.append({
            "resseq": int(resseq),
            "icode": icode.strip() or "",
            "x": float(ca[0]),
            "y": float(ca[1]),
            "z": float(ca[2]),
        })
    if not rows:
        return pd.DataFrame(columns=["seq_index","resseq","icode","x","y","z"])
    df = pd.DataFrame(rows)
    df = df.sort_values(["resseq","icode"], kind="mergesort").reset_index(drop=True)
    df.insert(0, "seq_index", np.arange(1, len(df)+1))
    return df

# ------------------------------ Main compute ------------------------------

def process_pdb_models(
    pdb_path: str,
    chain_id: Optional[str],
    model_mode: str,
    kappa_units: str
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns:
      per_residue_df, per_chain_df
    (Empty dataframes if nothing is computed.)
    """
    uniprot_id = stem_as_uniprot_id(pdb_path)

    parser = PDBParser(QUIET=True)
    structure = parser.get_structure(uniprot_id, pdb_path)
    models = list(structure.get_models())
    if not models:
        return pd.DataFrame(), pd.DataFrame()
    if model_mode == 'first':
        models = [models[0]]

    per_residue_records = []
    per_chain_records = []

    sf = nm_scale_factor(kappa_units)

    for model_idx, model in enumerate(models, start=1):
        chains = [c for c in model.get_chains()] if (chain_id is None or chain_id.lower()=="all") else [model[chain_id]]
        for ch in chains:
            df = residue_table_from_chain(ch)
            if df.empty:
                continue

            coords = df[["x","y","z"]].to_numpy(float)
            resseq = df["resseq"].tolist()
            icode  = df["icode"].tolist()

            # Detect breaks
            br = detect_chain_breaks(coords, resseq, icode, ca_ca_max=4.5)

            # Curvature
            kappa = compute_curvature_from_ca(coords, br) * sf  # convert units

            tmp = df.copy()
            tmp.insert(0, "uniprot_id", uniprot_id)
            tmp.insert(1, "pdb_file", os.path.basename(pdb_path))
            tmp.insert(2, "model_index", model_idx)
            tmp.insert(3, "chain", ch.id)
            tmp["kappa"] = kappa
            tmp["kappa_units"] = kappa_units

            per_residue_records.append(tmp)

            # Per-chain summary across entire chain (respecting breaks for arc length)
            mask_valid = np.isfinite(kappa)
            n_valid = int(mask_valid.sum())
            chain_len = int(len(df))
            # arc length: sum of CA-CA distances where no break between i and i+1
            arc = 0.0
            if len(coords) >= 2:
                diffs = np.linalg.norm(np.diff(coords, axis=0), axis=1)
                # br marks breaks BETWEEN i and i+1 at index i; include only where not break
                arc = float(np.sum(diffs[~br]))
            if n_valid > 0:
                kseg = kappa[mask_valid]
                k_mean = float(np.mean(kseg))
                k_median = float(np.median(kseg))
                k_std = float(np.std(kseg, ddof=1)) if n_valid > 1 else np.nan
            else:
                k_mean = k_median = k_std = np.nan

            per_chain_records.append({
                "uniprot_id": uniprot_id,
                "pdb_file": os.path.basename(pdb_path),
                "model_index": model_idx,
                "chain": ch.id,
                "chain_length_res": chain_len,
                "n_valid": n_valid,
                "frac_valid": (n_valid / max(chain_len, 1)),
                "kappa_units": kappa_units,
                "kappa_mean": k_mean,
                "kappa_median": k_median,
                "kappa_std": k_std,
                "arc_length_A": arc,
                "arc_length_nm": arc / 10.0
            })

    per_residue_df = pd.concat(per_residue_records, ignore_index=True) if per_residue_records else pd.DataFrame()
    per_chain_df = pd.DataFrame(per_chain_records) if per_chain_records else pd.DataFrame()
    return per_residue_df, per_chain_df

# ------------------------------ CLI ------------------------------

def _worker_process(args_tuple):
    pdb_path, chain_id, model_mode, units = args_tuple
    try:
        return process_pdb_models(pdb_path, chain_id, model_mode, units)
    except KeyError as e:
        print(f"[WARN] Skipping {os.path.basename(pdb_path)} due to error: {e}")
        return pd.DataFrame(), pd.DataFrame()
    except Exception as e:
        print(f"[WARN] Error on {os.path.basename(pdb_path)}: {e}")
        return pd.DataFrame(), pd.DataFrame()


def aggregate_per_chain(per_chain_df: pd.DataFrame, how: str = "mean") -> pd.DataFrame:
    """Aggregate per-model chain summaries into one row per (uniprot_id, pdb_file, chain).

    how: 'mean' (default) or 'median' for numeric columns.
    Notes:
      - chain_length_res: take max across models (should be identical if consistent)
      - kappa_units: take first (should be identical)
      - n_models: added as count of models aggregated
    """
    if per_chain_df.empty:
        return per_chain_df
    group_keys = ["uniprot_id", "pdb_file", "chain"]
    agg_fun = np.mean if how == "mean" else np.median

    def _agg_block(df: pd.DataFrame) -> pd.Series:
        out = {}
        out["chain_length_res"] = int(df["chain_length_res"].max()) if "chain_length_res" in df else np.nan
        out["n_models"] = int(len(df))
        if "n_valid" in df:
            out["n_valid"] = float(agg_fun(df["n_valid"].to_numpy(float)))
        if "frac_valid" in df:
            out["frac_valid"] = float(agg_fun(df["frac_valid"].to_numpy(float)))
        # kappa stats
        for col in ["kappa_mean", "kappa_median", "kappa_std", "arc_length_A", "arc_length_nm"]:
            if col in df:
                out[col] = float(agg_fun(df[col].to_numpy(float)))
        # keep units (assume constant)
        out["kappa_units"] = df["kappa_units"].iloc[0] if "kappa_units" in df and not df["kappa_units"].empty else "A-1"
        return pd.Series(out)

    agg_df = per_chain_df.groupby(group_keys, as_index=False).apply(_agg_block)
    # GroupBy.apply with as_index=False returns a DataFrame with index possibly named; reset_index just in case
    agg_df = agg_df.reset_index(drop=True)
    # Order columns nicely
    cols = ["uniprot_id", "pdb_file", "chain", "n_models", "chain_length_res", "n_valid", "frac_valid",
            "kappa_units", "kappa_mean", "kappa_median", "kappa_std", "arc_length_A", "arc_length_nm"]
    present = [c for c in cols if c in agg_df.columns]
    remaining = [c for c in agg_df.columns if c not in present]
    return agg_df[present + remaining]


def main():
    ap = argparse.ArgumentParser(description="Compute local chain curvature (κ) from PDB Cα traces across full chains.")
    ap.add_argument("--pdb-dir", required=True, help="Directory containing PDB files (single- or multi-model).")
    ap.add_argument("--glob", default="*.pdb", help="Glob for PDBs (default: *.pdb).")
    ap.add_argument("--chain-id", default="A",
                    help="Chain ID to process (e.g., 'A'). Use 'all' to process all chains in each PDB. Default: A")
    ap.add_argument("--model-mode", choices=["first","all"], default="all",
                    help="Whether to process only the first model or all models. Default: all")
    ap.add_argument("--units", choices=["A-1","nm-1"], default="A-1",
                    help="Units for curvature κ. Default: A-1")
    ap.add_argument("--outdir", default="./curvature_out", help="Output directory. Default: ./curvature_out")
    ap.add_argument("--aggregate-models", choices=["none","mean","median"], default="mean",
                    help="Aggregate per-model summaries into one row per chain using mean/median (default: mean). Use 'none' to keep per-model only.")
    ap.add_argument("--only-aggregate", action="store_true",
                    help="If set, write only the aggregated per-chain summary and skip per-model chain summary.")
    ap.add_argument("--n-proc", type=int, default=1, help="Number of worker processes (default: 1)")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    pdb_paths = sorted(glob(os.path.join(args.pdb_dir, args.glob)))
    if not pdb_paths:
        print(f"[WARN] No PDB files matched {os.path.join(args.pdb_dir, args.glob)}")

    tasks = [(p, args.chain_id, args.model_mode, args.units) for p in pdb_paths]
    all_per_res = []
    all_per_chain = []

    if args.n_proc and args.n_proc > 1:
        from concurrent.futures import ProcessPoolExecutor, as_completed
        with ProcessPoolExecutor(max_workers=args.n_proc) as ex:
            futs = [ex.submit(_worker_process, t) for t in tasks]
            for fut in as_completed(futs):
                per_res, per_chain = fut.result()
                if not per_res.empty:
                    all_per_res.append(per_res)
                if not per_chain.empty:
                    all_per_chain.append(per_chain)
    else:
        for t in tasks:
            per_res, per_chain = _worker_process(t)
            if not per_res.empty:
                all_per_res.append(per_res)
            if not per_chain.empty:
                all_per_chain.append(per_chain)

    if all_per_res:
        per_res_df = pd.concat(all_per_res, ignore_index=True)
        out_res = os.path.join(args.outdir, "per_residue_curvature.csv")
        per_res_df.to_csv(out_res, index=False)
        print(f"[OK] Wrote per-residue: {out_res}")
    else:
        print("[INFO] No per-residue data produced.")

    if all_per_chain:
        per_chain_df = pd.concat(all_per_chain, ignore_index=True)
        if not args.only_aggregate:
            out_chain = os.path.join(args.outdir, "per_chain_summary.csv")
            per_chain_df.to_csv(out_chain, index=False)
            print(f"[OK] Wrote per-chain summary (per-model): {out_chain}")
        # Aggregation step
        if args.aggregate_models != "none":
            agg_df = aggregate_per_chain(per_chain_df, how=args.aggregate_models)
            out_chain_agg = os.path.join(args.outdir, "per_chain_summary_aggregated.csv")
            agg_df.to_csv(out_chain_agg, index=False)
            print(f"[OK] Wrote aggregated per-chain summary: {out_chain_agg}")
    else:
        print("[INFO] No per-chain summary produced (no data).")

if __name__ == "__main__":
    main()
