'''
Main builder function for medium (beads-on-a-string) fast cases.

Number of IDR residues do not exceed 150 AA.

REQUIREMENTS
------------
* IDPConformerGenerator v0.7.25
* OpenMM v8.2.0
* pdb-tools v2.5.0
* PDBFixer v1.9.0
* Master database, IDs to process, folder of AF2-PDBs as templates

Date: January 30, 2025 (v1.5)
Author: Zi Hao Liu
'''
import re
import sys
import json
import os
import subprocess
import shutil

import numpy as np

from pdbfixer import PDBFixer
from functools import partial
from glob import glob
from time import sleep

from openmm.app import (
    PDBFile,
    ForceField,
    Simulation,
    HBonds,
    NoCutoff,
    )
from openmm import LangevinIntegrator, CustomExternalForce
from openmm.unit import *

from idpconfgen import Path
from idpconfgen.libs.libstructure import (
    Structure,
    col_resSeq,
    col_resName,
    col_name,
    cols_coords,
    col_chainID,
    col_segid,
    col_serial,
    structure_to_pdb,
    write_PDB,
    parse_pdb_to_array,
    )
from idpconfgen.ldrs_helper import (
    align_coords,
    count_clashes,
    )
from idpconfgen.libs.libmulticore import pool_function


# Change job parameters here.
# Set number will depend on the name of the script
set_num = int(re.search(r'\d+', sys.argv[0]).group())  
nconfs = 100
ncores = 16
cc_ncores = 5  # OpenMM can't multiprocess with all cores
sleep_time = 2  # seconds
output_directory = f"../AFX_Category2/Category2_ens{set_num}"
medium_ids_file = f"../databases/Category2_IDs/ID{set_num}.txt"
idpcg_database = "../databases/idpconfgen_database.json"
master_db_file = "../databases/AlphaFlex_database_Jul2024.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
af2_pdbs = glob("../databases/AF2_9606_PDB/*.pdb")


def resolve_clash(pdb_file):
    """
    Inspired by Oliver Sun.
    
    Resolve clashes in the protein file through short md simulation steps while keeping
    protein backbone fixed during the process.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    pdb = PDBFile(pdb_file)
    forcefield = ForceField('amber99sb.xml')

    # Set up the OpenMM system
    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Select side-chain atoms by excluding backbone atoms
    sidechain_atoms = []
    for atom in pdb.topology.atoms():
            sidechain_atoms.append(atom.index)

    # Apply harmonic constraints to backbone atoms
    k = 10.0 * kilocalories_per_mole / angstrom**2  # Adjust this if needed
    constraint_force = CustomExternalForce('0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)')
    constraint_force.addPerParticleParameter('x0')
    constraint_force.addPerParticleParameter('y0')
    constraint_force.addPerParticleParameter('z0')
    constraint_force.addGlobalParameter('k', k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:  # Apply only to backbone atoms
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    # Set up the simulation
    integrator = LangevinIntegrator(300*kelvin, 1/picosecond, 0.002*picoseconds) # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)

    # Minimize energy (with constraints active)
    simulation.minimizeEnergy(maxIterations=1000)

    # Save the minimized structure
    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(f"{folder}/{name}_cr.pdb", 'w') as f:
        PDBFile.writeFile(simulation.topology, positions, f)
    
    os.remove(pdb_file)


def add_hydrogens(pdb_file, pH=7.4):
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)
    
    PDBFile.writeFile(
        fixer.topology,
        fixer.positions,
        open(f'{folder}/{name}_pro.pdb', 'w')
        )
    
    os.remove(pdb_file)


def find_fld_domains(idrs, max_res):
    domains = []
    
    # Add the initial range if the first range doesn't start at 1
    if idrs[0][0] > 1:
        domains.append([1, idrs[0][0] - 1])
    
    # Add gaps
    domains.extend([[idrs[i][1] + 1, idrs[i+1][0] - 1] for i in range(len(idrs) - 1)])
    
    # Add the tail
    if idrs[-1][1] < max_res:
        domains.append([idrs[-1][1] + 1, max_res])
    
    return domains


def cterm_aligner(nterm, cterm, rs, output):
    nterm_struc = Structure(Path(nterm))
    nterm_struc.build()
    nterm_arr = nterm_struc.data_array
    n_name = nterm_struc.data_array[:, col_name]
    n_seq = nterm_struc.data_array[:, col_resSeq].astype(int)

    last_seq = n_seq[-1]
    
    nterm_idx = {}
    for j, _atom in enumerate(n_name):
        k = len(n_name) - 1 - j
        curr_seq = n_seq[k]
        if curr_seq == last_seq and n_name[k] == "N":
            nterm_idx["N"] = k
        elif curr_seq == last_seq and n_name[k] == "CA":
            nterm_idx["CA"] = k
        elif curr_seq == last_seq - 1 and n_name[k] == "C":
            nterm_idx["C"] = k
        elif curr_seq == last_seq - 2:
            break

    Cxyz = nterm_struc.data_array[nterm_idx["C"]][cols_coords].astype(float)
    Nxyz = nterm_struc.data_array[nterm_idx["N"]][cols_coords].astype(float)
    CAxyz = nterm_struc.data_array[nterm_idx["CA"]][cols_coords].astype(float)
    # Coordinates of boundary to stitch to later on
    align_tgt_coords = np.array([Cxyz, Nxyz, CAxyz])
    
    with open(cterm) as f:
        cterm_data = f.read()
    try:
        cterm_arr = parse_pdb_to_array(cterm_data)
    except AssertionError:
        return
    
    aligned_cterm = align_coords(cterm_arr, align_tgt_coords, "C-IDR")
    clashes, fragment = count_clashes(
        aligned_cterm,
        nterm_struc,
        "C-IDR",
        max_clash=100,
        tolerance=0.4
        )

    if type(clashes) is int:
        aligned_struc = structure_to_pdb(fragment)
        nterm_split = nterm.split("/")
        nterm_int = int(re.search(r'\d+', nterm_split[-1]).group())
        write_PDB(aligned_struc, output + f"/temp{rs}{nterm_int}.pdb")
        
        aligned_cterm_struc = Structure(Path(output + f"/temp{rs}{nterm_int}.pdb"))
        aligned_cterm_struc.build()
        aligned_cterm_arr = aligned_cterm_struc.data_array
        chain = nterm_arr[:, col_chainID][0]
        seq_nterm = nterm_arr[:, col_resSeq].astype(int)  
        seq_cterm = aligned_cterm_arr[:, col_resSeq].astype(int)
        
        # Correct chain ID
        for i, _ in enumerate(cterm_arr):
            cterm_arr[i][col_chainID] = chain
        
        # Remove first residue on C-term
        for i, seq in enumerate(seq_cterm):
            next = seq_cterm[i + 1]
            cterm_arr = cterm_arr[1:]
            if next != seq:
                break
            
        # remove last residue on N-term
        for i, _ in enumerate(seq_nterm):
            j = len(seq_nterm) - 1 - i
            curr = seq_nterm[j]
            prev = seq_nterm[j - 1]
            nterm_arr = nterm_arr[:-1]
            if prev != curr:
                break
            
        nterm_lst = nterm_arr.tolist()
        cterm_lst = cterm_arr.tolist()
        new_struc_lst = nterm_lst + cterm_lst
        
        new_struc_arr = np.array(new_struc_lst)
        
        new_serial = [str(i) for i in range(1, len(new_struc_arr) + 1)]
        new_struc_arr[:, col_serial] = new_serial
        new_struc_arr[:, col_segid] = ""
        for i, res in enumerate(new_struc_arr[:, col_resName]):
            if res == "HIP":
                new_struc_arr[:, col_resName][i] = "HIS"
        new_struc = structure_to_pdb(new_struc_arr)
        
        write_PDB(new_struc, output + f"/conformer_rs{rs}_{nterm_int}.pdb")
        os.remove(output + f"/temp{rs}{nterm_int}.pdb")
        
        return True
    
    return False


def cterm_stitcher(nterm_arr, cterm_arr, output, idx):
    chain = nterm_arr[:, col_chainID][0]
    seq_nterm = nterm_arr[:, col_resSeq].astype(int)  
    seq_cterm = cterm_arr[:, col_resSeq].astype(int)
    
    # Correct chain ID
    for i, _ in enumerate(cterm_arr):
        cterm_arr[i][col_chainID] = chain
    
    # Remove first residue on C-term
    for i, seq in enumerate(seq_cterm):
        next = seq_cterm[i + 1]
        cterm_arr = cterm_arr[1:]
        if next != seq:
            break
    
    # remove last residue on N-term
    for i, _ in enumerate(seq_nterm):
        j = len(seq_nterm) - 1 - i
        curr = seq_nterm[j]
        prev = seq_nterm[j - 1]
        nterm_arr = nterm_arr[:-1]
        if prev != curr:
            break
    
    nterm_lst = nterm_arr.tolist()
    cterm_lst = cterm_arr.tolist()
    new_struc_lst = nterm_lst + cterm_lst
    
    new_struc_arr = np.array(new_struc_lst)
    
    new_serial = [str(i) for i in range(1, len(new_struc_arr) + 1)]
    new_struc_arr[:, col_serial] = new_serial
    new_struc_arr[:, col_segid] = ""

    for i, res in enumerate(new_struc_arr[:, col_resName]):
        if res == "HIP":
            new_struc_arr[:, col_resName][i] = "HIS"
    new_struc = structure_to_pdb(new_struc_arr)
    
    write_PDB(new_struc, output + f"/conformer_{idx}.pdb")


# File path error checking
try:
    with open(master_db_file, 'r') as f:
        master_db = json.load(f)
    with open(medium_ids_file, 'r') as f:
        medium_ids = [line.strip() for line in f]
    with open(max_residues_file, 'r') as f:
        max_residues = json.load(f)
except FileNotFoundError:
    print("Error: file not found for databases. Please check paths.")
    exit()

# Set-up main output directory
if not os.path.exists(output_directory):
    os.mkdir(output_directory)
for id in medium_ids:
    # Set-up temporary directories
    path_final_ens = f"{output_directory}/{id}"
    path_templates = f"{path_final_ens}/temp_templates"
    path_idrs = f"{path_final_ens}/temp_idrs"
    path_passed = f"{path_final_ens}/temp_idrs_passed"
    path_wip = f"{path_final_ens}/temp_wip_conformers"
    path_wip2 = f"{path_final_ens}/temp_wip2_conformers"
    if not os.path.exists(path_final_ens):
        os.mkdir(path_final_ens)
    if not os.path.exists(path_templates):
        os.mkdir(path_templates)
    if not os.path.exists(path_idrs):
        os.mkdir(path_idrs)
    if not os.path.exists(path_passed):
        os.mkdir(path_passed)
    if not os.path.exists(path_wip):
        os.mkdir(path_wip)
    if not os.path.exists(path_wip2):
        os.mkdir(path_wip2)
    # Find entries in database
    pdb_path = [p for p in af2_pdbs if id in p][0]
    struc = Structure(Path(pdb_path))
    struc.build()
    struc_arr = struc.data_array
    struc_lst = struc_arr.tolist()
    sequence = next(iter(struc.fasta.values()))
    details = master_db[id]['idrs']
    num_res = max_residues[id]
    
    # Split the folded domains up
    fld_domains = find_fld_domains(details, num_res)
    for i, domain in enumerate(fld_domains):
        subdomain_lst = []
        start = domain[0]
        end = domain[1]
        fld_res = struc_arr[:, col_resSeq].astype(int)
        for j, res in enumerate(fld_res):
            if start <= res <= end:
                subdomain_lst.append(struc_lst[j])

        subdomain_struc = structure_to_pdb(np.array(subdomain_lst))
        write_PDB(subdomain_struc, path_templates + f"/{id}_d{i}.pdb")

    print(f"Building {nconfs} conformers for {id}...")
    
    # Get the IDR sequences in order
    idr_seqs = []
    cases = []
    if details[0][0] == 1 and details[-1][1] == num_res:  # All IDRs
        nidr_seq = sequence[:details[0][1] + 2]
        idr_seqs.append(nidr_seq)
        cases.append("N")
        cidr_seq = sequence[details[-1][0] - 3:]
        details.pop(0)
        details.pop(-1)
        for lidr in details:
            idr_seqs.append(sequence[lidr[0] - 3 : lidr[1] + 2])
            cases.append("L")
        idr_seqs.append(cidr_seq)
        cases.append("C")
    elif details[0][0] == 1:  # Only N-IDR + LIDRs
        nidr_seq = sequence[:details[0][1] + 2]
        idr_seqs.append(nidr_seq)
        cases.append("N")
        details.pop(0)
        for lidr in details:
            idr_seqs.append(sequence[lidr[0] - 3 : lidr[1] + 2])
            cases.append("L")
    elif details[-1][1] == num_res:  # Only L-IDRs + C-IDR
        cidr_seq = sequence[details[-1][0] - 3:]
        details.pop(-1)
        for lidr in details:
            idr_seqs.append(sequence[lidr[0] - 3 : lidr[1] + 2])
            cases.append("L")
        idr_seqs.append(cidr_seq)
        cases.append("C")
    else:  # Only L-IDRs
        for lidr in details:
            idr_seqs.append(sequence[lidr[0] - 3 : lidr[1] + 2])
            cases.append("L")

    # Building process
    for c, case in enumerate(cases):
        if case != "C":
            fld_path = path_templates + f"/{id}_d{c}.pdb"
            fld_struc = Structure(Path(fld_path))
            fld_struc.build()
            fld_seq = next(iter(fld_struc.fasta.values()))
            idr_seq = idr_seqs[c]

            try:
                next_fld_path = path_templates + f"/{id}_d{c + 1}.pdb"
                next_fld_struc = Structure(Path(next_fld_path))
                next_fld_struc.build()
                next_idr_seq = idr_seqs[c + 1]
            except Exception:
                pass
        
        if case == "N":
            # Builds -O-O, IDRs on both sides and ends with second folded domain
            num_passed = 0
            rs = 0
            while num_passed < nconfs:
                run_idpcg = subprocess.run(
                    [f"idpconfgen ldrs \
                        -fld {fld_path} \
                        -seq {idr_seq[:-2] + fld_seq + next_idr_seq[2:]} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -rs {rs} \
                        -nc {nconfs} -n {ncores} \
                        -of {path_idrs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
                
                ldrs_list = glob(f"{path_idrs}/*.pdb")
                execute = partial(
                    cterm_aligner,
                    cterm=next_fld_path,
                    rs=rs,
                    output=path_wip,
                    )
                execute_pool = pool_function(execute, ldrs_list, ncores=ncores)
                for _ in execute_pool:
                    pass
                rs += ncores
                frags_passed = glob(f"{path_wip}/*.pdb")
                num_passed = len(frags_passed)
            
            # Cleanup
            idrs_f = glob(path_idrs + "/*")
            for f in idrs_f:
                os.remove(f)
                
        elif case == "L":
            # If it's the first, build O-O
            if c == 0:
                num_passed = 0
                rs = 0
                while num_passed < nconfs:
                    run_idpcg = subprocess.run(
                        [f"idpconfgen ldrs \
                            -fld {fld_path} \
                            -seq {fld_seq + idr_seq[2:]} \
                            -db {idpcg_database} \
                            --dloop-off --dany \
                            -rs {rs} \
                            -nc {nconfs} -n {ncores} \
                            -of {path_idrs}"
                        ],
                        capture_output=True,  # Set this to False to see IDPCG CLI output
                        shell=True,
                        )

                    ldrs_list = glob(f"{path_idrs}/*.pdb")
                    execute = partial(
                        cterm_aligner,
                        cterm=next_fld_path,
                        rs=rs,
                        output=path_wip,
                        )
                    execute_pool = pool_function(execute, ldrs_list, ncores=ncores)
                    for _ in execute_pool:
                        pass
                    rs += ncores
                    frags_passed = glob(f"{path_wip}/*.pdb")
                    num_passed = len(frags_passed)
            # If it's in the middle, build a -O
            else:
                if cases[0] == "L":
                    frags_passed = glob(f"{path_wip}/*.pdb")
                    assert len(frags_passed) >= nconfs
                    for f, frag in enumerate(frags_passed):
                        wip2_passed = glob(path_wip2 + "/*.pdb")
                        if len(wip2_passed) == nconfs:
                            os.remove(frag)
                            continue
                        frag_struc = Structure(Path(frag))
                        frag_struc.build()
                        frag_seq = next(iter(frag_struc.fasta.values()))
                        passed = False
                        rs = 0
                        while passed == False:
                            run_idpcg = subprocess.run(
                                [f"idpconfgen ldrs \
                                    -fld {frag} \
                                    -seq {frag_seq + idr_seq[2:]} \
                                    -db {idpcg_database} \
                                    --dloop-off --dany \
                                    -rs {rs} \
                                    -nc 1 -n 1 \
                                    -of {path_idrs}"
                                ],
                                capture_output=True,  # Set this to False to see IDPCG CLI output
                                shell=True,
                                )
                            sleep(sleep_time)
                            try:
                                os.rename(path_idrs + "/conformer_1.pdb", path_idrs + f"/conformer_{f + 1}.pdb")
                            except FileNotFoundError:
                                print(run_idpcg.stdout)
                                exit()
                            passed = cterm_aligner(
                                nterm=path_idrs + f"/conformer_{f + 1}.pdb",
                                cterm=next_fld_path,
                                rs=rs,
                                output=path_wip2,
                                )
                            rs += 1
                        os.remove(frag)
                    
                    file_names = os.listdir(path_wip2)
                    for file_name in file_names:
                        shutil.move(os.path.join(path_wip2, file_name), path_wip)
                else:
                    # For cases that started with an N-IDR
                    # We are somewhere in the middle so we need to build an IDR
                    # and then attach another folded domain
                    skip_case = False
                    try:
                        next_case = cases[c + 1]
                        if next_case == "C":
                            skip_case = True
                    except IndexError:  # Last case has reached
                        skip_case = True
                    if skip_case:
                        continue
                    else:
                        frags_passed = glob(f"{path_wip}/*.pdb")
                        assert len(frags_passed) >= nconfs
                        for f, frag in enumerate(frags_passed):
                            check_passed = glob(path_passed + "/*.pdb")
                            if len(check_passed) == nconfs:
                                os.remove(frag)
                                continue
                            frag_struc = Structure(Path(frag))
                            frag_struc.build()
                            frag_seq = next(iter(frag_struc.fasta.values()))
                            passed = False
                            rs = 0
                            while passed == False:
                                run_idpcg = subprocess.run(
                                    [f"idpconfgen ldrs \
                                        -fld {frag} \
                                        -seq {frag_seq + next_idr_seq[2:]} \
                                        -db {idpcg_database} \
                                        --dloop-off --dany \
                                        -rs {rs} \
                                        -nc 1 -n 1 \
                                        -of {path_idrs}"
                                    ],
                                    capture_output=True,  # Set this to False to see IDPCG CLI output
                                    shell=True,
                                    )
                                sleep(sleep_time)
                                try:
                                    os.rename(path_idrs + "/conformer_1.pdb", path_idrs + f"/conformer_{f + 1}.pdb")
                                except FileNotFoundError:
                                    print(run_idpcg.stdout)
                                    exit()
                                passed = cterm_aligner(
                                    nterm=path_idrs + f"/conformer_{f + 1}.pdb",
                                    cterm=next_fld_path,
                                    rs=rs,
                                    output=path_passed,
                                    )
                                rs += 1
                            os.remove(frag)
                        frags_passed = glob(f"{path_passed}/*.pdb")
                        for num in range(1, nconfs + 1):
                            index = num - 1
                            shutil.move(frags_passed[index], path_wip + f"/conformer_{num}.pdb")
            # Cleanup
            idrs_f = glob(path_idrs + "/*")
            passed_f = glob(path_passed + "/*")
            for f in idrs_f:
                os.remove(f)
            for f in passed_f:
                os.remove(f)
        
        else:  # C-IDR case
            frags_passed = glob(f"{path_wip}/*.pdb")
            assert len(frags_passed) >= nconfs
            for f, frag in enumerate(frags_passed):
                frag_struc = Structure(Path(frag))
                frag_struc.build()
                frag_seq = next(iter(frag_struc.fasta.values()))
                run_idpcg = subprocess.run(
                    [f"idpconfgen ldrs \
                        -fld {frag} \
                        -seq {frag_seq + idr_seq[2:]} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -rs {rs} \
                        -nc 1 -n 1 \
                        -of {path_idrs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
                os.remove(frag)
                shutil.move(path_idrs + "/conformer_1.pdb", frag)

    # Move completed conformers to correct folder
    wip_confs = os.listdir(path_wip)
    for f in range(0, nconfs):
        src_path = os.path.join(path_wip, wip_confs[f])
        dst_path = os.path.join(path_final_ens, wip_confs[f])
        shutil.move(src_path, dst_path)
    
    print("Adding hydrogens...")
    idpcg_files = glob(f"{path_final_ens}/*.pdb")
    assert len(idpcg_files) == nconfs
    fix_atoms_pool = pool_function(add_hydrogens, idpcg_files, ncores=ncores)
    for _ in fix_atoms_pool:
        pass
    
    print("Resolving side-chain clashes...")
    hydrogenated_files = glob(f"{path_final_ens}/*.pdb")
    cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
    for _ in cc_pool:
        pass

    # Make PDBs as an ensemble file to save space
    run_pdbtools = subprocess.run(
            [f"pdb_mkensemble {path_final_ens}/*.pdb > {path_final_ens}/{id}_idpcg_n{nconfs}.pdb"],
            capture_output=True,  # Set this to False to see IDPCG CLI output
            shell=True,
            )
    
    # Cleanup temporary files
    os.system(f"rm -rf {path_final_ens}/conformer*")
    os.system(f"rm -rf {path_final_ens}/temp*")
    os.system(f"rm -rf {path_final_ens}/energies.log")
    print(f"Finished: {id}.")
