from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Tuple

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

AXIS_LABEL_FONTSIZE = 18
TICK_LABEL_FONTSIZE = 16

# ------------------------------ Helpers ------------------------------

def load_csv(path: Path) -> pd.DataFrame:
    try:
        return pd.read_csv(path)
    except Exception as e:
        raise SystemExit(f"Failed to read CSV '{path}': {e}")


def ensure_arc_length_nm(df: pd.DataFrame) -> pd.DataFrame:
    """Add column 'arc_length_nm' if missing (derive from arc_length_A / 10)."""
    if 'arc_length_nm' in df.columns and df['arc_length_nm'].notna().any():
        df['arc_length_nm'] = df['arc_length_nm'].astype(float)
        return df
    if 'arc_length_A' in df.columns:
        df['arc_length_nm'] = df['arc_length_A'].astype(float) / 10.0
        return df
    raise ValueError("Input DataFrame lacks both 'arc_length_nm' and 'arc_length_A' columns")


def convert_kappa_to_nm_inv(df: pd.DataFrame) -> pd.DataFrame:
    if 'kappa_units' not in df.columns:
        return df  # assume already nm^-1 or unknown; skip
    units = df['kappa_units'].astype(str).str.lower()
    # Map synonyms
    is_ang = units.isin(['a-1', 'angstrom^-1', 'ang^-1', 'å^-1'])
    is_nm = units.isin(['nm-1', 'nanometer^-1'])
    if 'kappa_mean' not in df.columns:
        raise ValueError("DataFrame missing 'kappa_mean' column")
    df['kappa_mean_nm_inv'] = np.where(is_ang, df['kappa_mean'].astype(float) * 10.0,
                                       df['kappa_mean'].astype(float))
    return df


def extract_base_id(uniprot_id: str) -> str:
    # Split at first underscore; if none present return original
    if not isinstance(uniprot_id, str):
        return str(uniprot_id)
    parts = uniprot_id.split('_', 1)
    return parts[0]


def gather_segment_rows(segments_dir: Path, glob_pat: str) -> pd.DataFrame:
    rows = []
    for root, _, files in os.walk(segments_dir):
        for fn in files:
            if not fn.lower().endswith('.csv'):
                continue
            if glob_pat and not fn.endswith(glob_pat) and glob_pat != '*.csv':
                # simple suffix match fallback; if glob is '*.csv' we accept all
                pass  # allow walking further; detailed glob handled below
            path = Path(root) / fn
            try:
                df = load_csv(path)
            except SystemExit:
                continue
            if 'uniprot_id' not in df.columns:
                continue
            df = ensure_arc_length_nm(df)
            df = convert_kappa_to_nm_inv(df)
            rows.append(df)
    if not rows:
        return pd.DataFrame(columns=['uniprot_id','arc_length_nm','kappa_mean_nm_inv'])
    return pd.concat(rows, ignore_index=True)

# ------------------------------ Plot Logic ------------------------------

def build_overlay(master_df: pd.DataFrame,
                  segments_df: pd.DataFrame,
                  min_frac_valid: float | None = None) -> Tuple[pd.DataFrame, pd.DataFrame]:
    master_df = ensure_arc_length_nm(master_df)
    master_df = convert_kappa_to_nm_inv(master_df)
    # Filter master by frac_valid if requested
    if min_frac_valid is not None and 'frac_valid' in master_df.columns:
        master_df = master_df[master_df['frac_valid'].astype(float) >= min_frac_valid].copy()
    # Build set of base IDs from master
    base_ids = set(master_df['uniprot_id'].astype(str))  # master already base IDs
    # Prepare segments
    if segments_df.empty:
        return master_df, segments_df
    segments_df['base_id'] = segments_df['uniprot_id'].astype(str).map(extract_base_id)
    # Filter by frac_valid if requested
    if min_frac_valid is not None and 'frac_valid' in segments_df.columns:
        segments_df = segments_df[segments_df['frac_valid'].astype(float) >= min_frac_valid].copy()
    segments_filtered = segments_df[segments_df['base_id'].isin(base_ids)].copy()
    return master_df, segments_filtered


def plot_overlay(master_df: pd.DataFrame,
                 segments_df: pd.DataFrame,
                 out_png: Path,
                 alpha_master: float = 0.25,
                 alpha_segments: float = 0.25,
                 size_master: int = 6,
                 size_segments: int = 6) -> None:
    if master_df.empty and segments_df.empty:
        raise SystemExit("No data to plot after filtering.")
    plt.figure(figsize=(6, 4))
    if not master_df.empty:
        plt.scatter(master_df['arc_length_nm'], master_df['kappa_mean_nm_inv'],
                    c='black', marker="o", s=size_master, alpha=alpha_master, edgecolors='none', label='AlphaFold')
    if not segments_df.empty:
        plt.scatter(segments_df['arc_length_nm'], segments_df['kappa_mean_nm_inv'],
                    c='red', marker="o", s=size_segments, alpha=alpha_segments, edgecolors='none', label='AlphaFlex')
    plt.xlabel('Arc length (nm)', fontsize=AXIS_LABEL_FONTSIZE)
    plt.ylabel('Mean curvature ⟨κ⟩ (nm⁻¹)', fontsize=AXIS_LABEL_FONTSIZE)
    ax = plt.gca()
    ax.tick_params(axis='both', labelsize=TICK_LABEL_FONTSIZE)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_png, dpi=300)
    plt.close()

# ------------------------------ CLI ------------------------------

def parse_args(argv=None):
    ap = argparse.ArgumentParser(description='Overlay curvature scatter: master vs segment CSV collections.')
    ap.add_argument('--master-csv', required=True, help='Path to master CSV (e.g. per_idr_summary.csv).')
    ap.add_argument('--segments-dir', required=True, help='Directory containing segment CSV files.')
    ap.add_argument('--glob', default='*.csv', help='Glob pattern for segment CSV filenames (default: *.csv).')
    ap.add_argument('--min-frac-valid', type=float, default=None, help='Filter rows with frac_valid below this threshold.')
    ap.add_argument('-o', '--out', required=True, help='Output PNG path.')
    ap.add_argument('--write-merged-csv', action='store_true', help='Also write merged filtered dataset to CSV next to PNG.')
    return ap.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    master_path = Path(args.master_csv)
    seg_dir = Path(args.segments_dir)
    if not master_path.is_file():
        raise SystemExit(f"Master CSV not found: {master_path}")
    if not seg_dir.is_dir():
        raise SystemExit(f"Segments directory not found: {seg_dir}")

    master_df = load_csv(master_path)
    segments_df = gather_segment_rows(seg_dir, args.glob)

    master_filt, segments_filt = build_overlay(master_df, segments_df, min_frac_valid=args.min_frac_valid)

    out_png = Path(args.out)
    out_png.parent.mkdir(parents=True, exist_ok=True)
    plot_overlay(master_filt, segments_filt, out_png)

    if args.write_merged_csv:
        merged_path = out_png.with_suffix('.merged.csv')
        # Add a source column to allow distinguishing in downstream analysis
        master_tagged = master_filt.copy()
        master_tagged['source'] = 'master'
        segments_tagged = segments_filt.copy()
        segments_tagged['source'] = 'segments'
        merged = pd.concat([master_tagged, segments_tagged], ignore_index=True)
        merged.to_csv(merged_path, index=False)
        print(f"[OK] Wrote merged CSV: {merged_path}")

    print(f"[OK] Wrote overlay plot: {out_png}")
    print(f"Master rows plotted: {len(master_filt)} | Segment rows plotted: {len(segments_filt)}")

if __name__ == '__main__':
    raise SystemExit(main())
