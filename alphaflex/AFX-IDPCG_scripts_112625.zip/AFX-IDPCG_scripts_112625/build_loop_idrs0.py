'''
Main builder for 'hard easy' cases where a single IDR is between fixed folded domains.
Uses existing IDPConformerGenerator logic.

REQUIREMENTS
------------
* IDPConformerGenerator v0.7.29
* Master database, IDs to process, folder of AF2-PDBs, sequence database.

Date: September 22, 2025 (v1.1)
Author: Zi Hao Liu
'''
import re
import sys
import json
import os
import subprocess
import traceback

import numpy as np

from pdbfixer import PDBFixer
from functools import partial
from glob import glob

from openmm.app import (
    PDBFile,
    ForceField,
    Simulation,
    HBonds,
    NoCutoff,
    )
from openmm import LangevinIntegrator, CustomExternalForce
from openmm.unit import *

from idpconfgen import Path
from idpconfgen.libs.libstructure import (
    Structure,
    col_resSeq,
    col_name,
    cols_coords,
    col_serial,
    structure_to_pdb,
    write_PDB,
    parse_pdb_to_array,
    )
from idpconfgen.ldrs_helper import (
    next_seeker,
    psurgeon,
    align_coords,
    count_clashes,
    structure_to_pdb,
    )
from idpconfgen.libs.libmulticore import pool_function


# Change job parameters here.
set_num = int(re.search(r'\d+', sys.argv[0]).group()) 
nconfs = 100
ncores = 16
cc_ncores = 5  # cores for clash correction
multiplier = 100
error_file = f"../databases/Cat3_errors/Cat3{set_num}_errors.txt"
output_directory = f"../AFX_Category3/cat3_set_{set_num}"
idpcg_database = "../databases/idpconfgen_database.json"
hard_single_ids_file = f"../databases/Category3_IDs/ID{set_num}.txt"
master_db_file = "../databases/AlphaFlex_database_Jul2024.json"
sequences_file = "../databases/AF2_9606_HUMAN_v4_sequences.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
af2_pdbs = glob("../databases/AF2_9606_PDB/*.pdb")


def resolve_clash(pdb_file):
    """
    Inspired by Oliver Sun.
    
    Resolve clashes in the protein file through short md simulation steps while keeping
    protein backbone fixed during the process.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    pdb = PDBFile(pdb_file)
    forcefield = ForceField('amber99sb.xml')

    # Set up the OpenMM system
    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Select side-chain atoms by excluding backbone atoms
    sidechain_atoms = []
    for atom in pdb.topology.atoms():
            sidechain_atoms.append(atom.index)

    # Apply harmonic constraints to backbone atoms
    k = 10.0 * kilocalories_per_mole / angstrom**2  # Adjust this if needed
    constraint_force = CustomExternalForce('0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)')
    constraint_force.addPerParticleParameter('x0')
    constraint_force.addPerParticleParameter('y0')
    constraint_force.addPerParticleParameter('z0')
    constraint_force.addGlobalParameter('k', k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:  # Apply only to backbone atoms
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    # Set up the simulation
    integrator = LangevinIntegrator(300*kelvin, 1/picosecond, 0.002*picoseconds) # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)

    # Minimize energy (with constraints active)
    simulation.minimizeEnergy(maxIterations=1000)

    # Save the minimized structure
    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(f"{folder}/{name}_cr.pdb", 'w') as f:
        PDBFile.writeFile(simulation.topology, positions, f)
    
    os.remove(pdb_file)


def add_hydrogens(pdb_file, pH=7.4):
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)
    
    PDBFile.writeFile(
        fixer.topology,
        fixer.positions,
        open(f'{folder}/{name}_pro.pdb', 'w')
        )
    
    os.remove(pdb_file)


def remove_af2_lidr(struc, id, lidr_residues, output_dir):
    data_arr = struc.data_array
    data_lst = list(data_arr)
    af2_resnum = data_arr[:, col_resSeq].astype(int)
    lidr_res_full = range(lidr_residues[0], lidr_residues[1] + 1)
    lidr_res_pro = range(lidr_residues[0] - 1, lidr_residues[1] + 2)
    cleaned_arr = []
    processed_arr = []
    for i, res in enumerate(af2_resnum):
        if res not in lidr_res_full:
            cleaned_arr.append(data_lst[i])
        
        if res not in lidr_res_pro:
            processed_arr.append(data_lst[i])
    
    cleaned_arr = np.array(cleaned_arr)
    new_serials = np.arange(1, len(cleaned_arr) + 1)
    cleaned_arr[:, col_serial] = new_serials
    
    processed_arr = np.array(processed_arr)
    new_serials = np.arange(1, len(processed_arr) + 1)
    processed_arr[:, col_serial] = new_serials

    cleaned_struc = structure_to_pdb(cleaned_arr)
    processed_struc = structure_to_pdb(processed_arr)
    write_PDB(cleaned_struc, output_dir + f"/{id}_cleaned.pdb")
    write_PDB(processed_struc, output_dir + f"/{id}_processed.pdb")


def break_idr_attach(idr, fld, upper, lower, run, output_upper=False, output_lower=False):
    fld_struc = Structure(Path(fld))
    fld_struc.build()
    atom_names = fld_struc.data_array[:, col_name]
    fld_seq = fld_struc.data_array[:, col_resSeq].astype(int)
    first_seq = fld_seq[0]
    if first_seq > 1:
        fld_seq -= first_seq - 1
        first_seq = fld_seq[0]
    
    fld_term_idx = {}
    for s, aa in enumerate(fld_seq):
        if aa == lower - 1 and atom_names[s] == 'C':
            fld_term_idx["CL"] = s
        elif aa == lower:
            if atom_names[s] == 'N':
                fld_term_idx["NL"] = s
            elif atom_names[s] == 'CA':
                fld_term_idx["CAL"] = s
        elif aa == upper and atom_names[s] == 'C':
            fld_term_idx['CU'] = s
        elif aa == upper + 1:
            if atom_names[s] == 'N':
                fld_term_idx['NU'] = s
            elif atom_names[s] == 'CA':
                fld_term_idx['CAU'] = s
        if aa > upper + 1:
            break
    
    fld_CLxyz = fld_struc.data_array[fld_term_idx["CL"]][cols_coords].astype(float)
    fld_NLxyz = fld_struc.data_array[fld_term_idx["NL"]][cols_coords].astype(float)
    fld_CALxyz = fld_struc.data_array[fld_term_idx["CAL"]][cols_coords].astype(float)
    fld_coords_L = np.array([fld_CLxyz, fld_NLxyz, fld_CALxyz])
    
    fld_CUxyz = fld_struc.data_array[fld_term_idx["CU"]][cols_coords].astype(float)
    fld_NUxyz = fld_struc.data_array[fld_term_idx["NU"]][cols_coords].astype(float)
    fld_CAUxyz = fld_struc.data_array[fld_term_idx["CAU"]][cols_coords].astype(float)
    fld_coords_U = np.array([fld_CUxyz, fld_NUxyz, fld_CAUxyz])
    
    with open(idr) as f:
        idr_data = f.read()
    try:
        idr_arr = parse_pdb_to_array(idr_data)
    except AssertionError:
        return
    
    if output_lower:
        aligned_break_L = align_coords(idr_arr, fld_coords_L, "C-IDR")
        clashesL, fragmentL = count_clashes(
            aligned_break_L,
            fld_struc,
            "C-IDR",
            max_clash=100,
            tolerance=1.0
            )
        if type(clashesL) is int:
            aligned_struc = structure_to_pdb(fragmentL)
            idr_split = idr.split("/")
            idr_int = int(re.search(r'\d+', idr_split[-1]).group())
            write_PDB(aligned_struc, output_lower + f"/run{run}_aligned_L_{idr_int}.pdb")
    
    elif output_upper:
        aligned_break_U = align_coords(idr_arr, fld_coords_U, "N-IDR")
        clashesU, fragmentU = count_clashes(
            aligned_break_U,
            fld_struc,
            "N-IDR",
            max_clash=100,
            tolerance=1.0
            )
        if type(clashesU) is int:
            aligned_struc = structure_to_pdb(fragmentU)
            idr_split = idr.split("/")
            idr_int = int(re.search(r'\d+', idr_split[-1]).group())
            write_PDB(aligned_struc, output_upper + f"/run{run}_aligned_U_{idr_int}.pdb")


def check_and_stitch(idr_path, fld_path, num, ranges, output):
    new_struc_arr = psurgeon(
        {"A": [Path(idr_path)]},
        Path(fld_path),
        {"A": ["Linker-IDR"]},
        {"A": ranges},
        )
    
    new_struc = structure_to_pdb(new_struc_arr)
    output_p = output + f"/conformer_{num + 1}.pdb"
    with open(output_p, 'w') as f:
        for line in new_struc:
            f.write(line + "\n")


def keep_n_files(folder, n=100):
    files = sorted(glob(os.path.join(folder, "*")))  # sort for reproducibility
    if len(files) > n:
        for f in files[:-n]:
            if os.path.isfile(f):
                os.remove(f)


# Processing below
try:
    with open(master_db_file, 'r') as f:
        master_db = json.load(f)
    with open(hard_single_ids_file, 'r') as f:
        hard_easy_ids = [line.strip() for line in f]
    with open(max_residues_file, 'r') as f:
        max_residues = json.load(f)
    with open(sequences_file, 'r') as f:
        sequences = json.load(f)
except FileNotFoundError:
    print("Error: file not found for database, IDs, or max residues. Please check paths.")
    exit()
os.makedirs(output_directory, exist_ok=True)


for id in hard_easy_ids:
    try:
        # Set-up temporary directories
        path_final_ens = f"{output_directory}/{id}"
        path_lidr_temp = f"{path_final_ens}/lidr_temp"
        path_lidr_confs = f"{path_lidr_temp}/confs"
        path_lidr_U = f"{path_lidr_temp}/U"
        path_lidr_L = f"{path_lidr_temp}/L"
        path_lidr_results = f"{path_lidr_temp}/results"
        os.makedirs(path_final_ens, exist_ok=True)
        os.makedirs(path_lidr_temp, exist_ok=True)
        os.makedirs(path_lidr_confs, exist_ok=True)
        os.makedirs(path_lidr_U, exist_ok=True)
        os.makedirs(path_lidr_L, exist_ok=True)
        os.makedirs(path_lidr_results, exist_ok=True)
        # Find entries in databases
        pdb_path = [p for p in af2_pdbs if id in p][0]
        details = master_db[id]['idrs']
        print(f"Building {nconfs} conformers for {id}...")
        start_res = int(details[0][0])
        end_res = int(details[0][1])
        start_i = start_res - 3
        end_i = end_res + 2
        lidr_seq = sequences[id][start_i:end_i]
        # Cleanup the AF2 structure
        af2_pdb_struc = Structure(Path(pdb_path))
        af2_pdb_struc.build()
        remove_af2_lidr(af2_pdb_struc, id, (start_res, end_res), path_lidr_temp)
        pdb_fld = path_lidr_temp + f"/{id}_cleaned.pdb"
        pdb_pro = path_lidr_temp + f"/{id}_processed.pdb"
        # Build using IDPCG
        num_success = len(glob(path_lidr_results + "/*.pdb"))
        rs_lidr = 0
        run = 1
        while num_success < nconfs:
            if len(lidr_seq) >= 150:
                run_idpcg = subprocess.run(
                    [f"idpconfgen build \
                        -seq {lidr_seq} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -nc {nconfs * multiplier} -n {ncores} \
                        -rs {rs_lidr} --long --force-long \
                        -of {path_lidr_confs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
            else:
                run_idpcg = subprocess.run(
                    [f"idpconfgen build \
                        -seq {lidr_seq} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -nc {nconfs * multiplier} -n {ncores} \
                        -rs {rs_lidr} \
                        -of {path_lidr_confs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
            idrs_list = glob(path_lidr_confs + "/*.pdb")
            execute = partial(
                break_idr_attach,
                    fld=pdb_fld,
                    upper=end_res + 1,
                    lower=start_res - 1,
                    run=run,
                    output_upper=path_lidr_U,
                    output_lower=False,
                )
            execute_pool = pool_function(execute, idrs_list, ncores=ncores)
            for _ in execute_pool:
                pass
            
            execute = partial(
                break_idr_attach,
                    fld=pdb_fld,
                    upper=end_res + 1,
                    lower=start_res - 1,
                    run=run,
                    output_upper=False,
                    output_lower=path_lidr_L,
                )
            execute_pool = pool_function(execute, idrs_list, ncores=ncores)
            for _ in execute_pool:
                pass
            
            idr_lower = glob(path_lidr_L + "/*.pdb")
            idr_upper = glob(path_lidr_U + "/*.pdb")
            execute = partial(
                next_seeker,
                nterm_idr_lib=idr_upper,
                max_clash=40,
                tolerance=0.4,
                output_folder=path_lidr_results,
                )
            execute_pool = pool_function(execute, idr_lower, ncores=ncores)
            for _ in execute_pool:
                pass
            
            run += 1
            rs_lidr += ncores + 1
            num_success = len(glob(path_lidr_results + "/*.pdb"))
        keep_n_files(path_lidr_results, nconfs)
        lidr_results = glob(path_lidr_results + "/*.pdb")
        for i, conf in enumerate(lidr_results):
            check_and_stitch(conf, pdb_fld, i, [(start_res - 1, end_res)], path_final_ens)
        
        print("Adding hydrogens...")
        idpcg_files = glob(f"{path_final_ens}/*.pdb")
        #assert len(idpcg_files) == nconfs
        fix_atoms_pool = pool_function(add_hydrogens, idpcg_files, ncores=ncores)
        for _ in fix_atoms_pool:
            pass
        
        print("Resolving side-chain clashes...")
        hydrogenated_files = glob(f"{path_final_ens}/*.pdb")
        cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
        for _ in cc_pool:
            pass
        
        # Make PDBs as an ensemble file to save space
        run_pdbtools = subprocess.run(
                [f"pdb_mkensemble {path_final_ens}/*.pdb > {path_final_ens}/{id}_idpcg_n{nconfs}.pdb"],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )
        
        # Cleanup temporary files
        os.system(f"rm -rf {path_final_ens}/conformer*")
        os.system(f"rm -rf {path_lidr_temp}")
        print(f"Finished: {id}.")        
    except Exception as e:
        with open(error_file, "a") as logf:
            logf.write(f"{id}: {e}\n")
            tb = traceback.format_exc()
            logf.write(tb + "\n\n")
        continue
