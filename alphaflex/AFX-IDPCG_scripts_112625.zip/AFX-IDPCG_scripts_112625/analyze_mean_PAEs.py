import json
import numpy as np
import glob
import os
import chardet
import multiprocessing
from tqdm import tqdm


def load_json(file_path):
    encodings = ['utf-8', 'latin-1', 'cp1252']
    
    with open(file_path, "rb") as f:
        raw_data = f.read()
        detected_encoding = chardet.detect(raw_data)['encoding']
    
    if detected_encoding:
        encodings.insert(0, detected_encoding)

    for encoding in encodings:
        try:
            with open(file_path, "r", encoding=encoding) as f:
                return json.load(f)
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue

    print(f"Warning: Skipping JSON file {file_path} due to encoding issues.")
    return None


def process_single_protein(protein_id, pae_path, idr_data, max_residues, threshold, progress_counter):
    """Processes a single protein's PAE file and updates progress"""
    if protein_id not in idr_data or protein_id not in max_residues:
        with progress_counter.get_lock():
            progress_counter.value += 1
        return None

    pae_data = load_json(pae_path)
    if pae_data is None or "predicted_aligned_error" not in pae_data[0]:
        print(f"Warning: Skipping {protein_id}, invalid PAE data.")
        with progress_counter.get_lock():
            progress_counter.value += 1
        return None

    pae_matrix = pae_data[0]["predicted_aligned_error"]
    idr_ranges = idr_data[protein_id]
    max_res = max_residues[protein_id]
    folded_domains = []

    ### **Assign Folded Domains Correctly**
    prev_end = 0
    for idr_start, idr_end in idr_ranges:
        if prev_end + 1 <= idr_start - 1:
            folded_domains.append([prev_end + 1, idr_start - 1])
        prev_end = idr_end

    if prev_end + 1 <= max_res:
        folded_domains.append([prev_end + 1, max_res])

    ### **Correctly Label IDRs and Folded Domains**
    all_regions = []
    labels = []
    dis_idx, fold_idx = 1, 1

    for region in idr_ranges:
        labels.append(f"D{dis_idx}")
        all_regions.append(region)
        dis_idx += 1

    for region in folded_domains:
        labels.append(f"F{fold_idx}")
        all_regions.append(region)
        fold_idx += 1

    ### **Compute Mean PAE with Correct Labels**
    mean_pae_values = {}
    matrix_size = len(pae_matrix)
    num_regions = len(all_regions)

    for i in range(num_regions):
        for j in range(i + 1, num_regions):
            range1 = all_regions[i]
            range2 = all_regions[j]

            indices1 = [idx for idx in range(range1[0] - 1, range1[1]) if 0 <= idx < matrix_size]
            indices2 = [idx for idx in range(range2[0] - 1, range2[1]) if 0 <= idx < matrix_size]

            if not indices1 or not indices2:
                print(f"Warning: Skipping mean PAE computation for {labels[i]} and {labels[j]} due to index out of bounds.")
                continue

            values = [pae_matrix[a][b] for a in indices1 for b in indices2 if 0 <= b < matrix_size]
            mean_pae = np.mean(values) if values else float('nan')

            mean_pae_values[f"{labels[i]}-{labels[j]}"] = round(mean_pae, 2) if not np.isnan(mean_pae) else None

    ### **Store Only Folded-Folded (F-F) Interactions**
    interactions = []
    folded_indices = [idx for idx, lbl in enumerate(labels) if lbl.startswith("F")]
    for i in folded_indices:
        for j in folded_indices:
            if i < j:
                key = f"{labels[i]}-{labels[j]}"
                if mean_pae_values.get(key) is not None and mean_pae_values[key] < threshold:
                    interactions.append([labels[i], labels[j]])

    # Update progress bar
    progress_counter.value += 1

    return {
        "protein_id": protein_id,
        "idrs": idr_ranges,
        "mean_pae": mean_pae_values,
        "interactions": interactions
    }


def process_pae_data_parallel(pae_folder, idr_file, max_residues_file, output_file, threshold=15, ncores=None):
    """Processes all PAE data files using multiprocessing with a progress bar"""

    # Load shared data once before multiprocessing
    idr_data = load_json(idr_file)
    max_residues = load_json(max_residues_file)

    if idr_data is None or max_residues is None:
        print("Error: Failed to load IDR or max residues data.")
        return

    # List all PAE JSON files
    pae_files = glob.glob(os.path.join(pae_folder, "*.json"))
    protein_entries = [(os.path.basename(f).replace(".json", ""), f) for f in pae_files]

    # Set number of workers
    ncores = ncores or multiprocessing.cpu_count() - 1  # Use all except 1 core
    print(f"Using {ncores} parallel workers.")

    # Shared counter for progress tracking
    manager = multiprocessing.Manager()
    progress_counter = manager.Value("i", 0)

    # Start progress bar in a separate process
    total_files = len(protein_entries)
    with tqdm(total=total_files, desc="Processing Proteins", unit="protein") as pbar:
        with multiprocessing.Pool(ncores) as pool:
            results = pool.starmap_async(
                process_single_protein,
                [(protein_id, pae_path, idr_data, max_residues, threshold, progress_counter) for protein_id, pae_path in protein_entries]
            )

            # Live update tqdm bar
            while not results.ready():
                pbar.n = progress_counter.value
                pbar.refresh()
        
            results = results.get()  # Wait for all results

    # Merge valid results
    master_database = {}
    for result in results:
        if result:
            master_database[result["protein_id"]] = {
                "idrs": result["idrs"],
                "mean_pae": result["mean_pae"],
                "interactions": result["interactions"]
            }

    # Save output
    with open(output_file, "w") as f:
        json.dump(master_database, f, indent=4)

    print(f"Processing complete! Results saved to {output_file}")


# Example usage
if __name__ == "__main__":
    pae_folder = "../databases/AF2_9606_PAE_JSON"  
    idr_file = "../min_consec_analysis/union/union_of_IDRS_min15_fixed.json"
    max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
    output_file = "../databases/min15_updated_PAE_master_db_fixed.json"
    ncores = 32

    process_pae_data_parallel(pae_folder, idr_file, max_residues_file, output_file, ncores=ncores)
