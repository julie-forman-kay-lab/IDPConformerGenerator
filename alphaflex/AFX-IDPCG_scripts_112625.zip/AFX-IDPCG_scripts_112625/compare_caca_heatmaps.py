"""
Compute delta CA-CA heatmaps (ensemble mean - AF2) from two folders of
normalized CSV heatmaps produced by the plotting scripts.

Usage: python compare_caca_heatmaps.py --ids ids.txt --af2-dir af2_csvs/ --ens-dir ens_csvs/ -o out_dir/

The script expects CSV files with a leading empty header cell then column
labels (1..N) and the first column containing row labels (1..N). This is the
format produced by the heatmap export scripts in this repo. The script will
read the numeric matrix for each file, check shape/labels compatibility and
compute delta = ensemble - af2. Results are saved as a PNG and a CSV for each
ID in the output directory.
"""
from __future__ import annotations

import argparse
import glob
import os
from pathlib import Path
import warnings

import numpy as np


def find_csv_for_id(directory: str, uid: str) -> str | None:
    """Find a CSV in directory that starts with uid and ends with 'caca_heatmap.csv'.
    If multiple matches, return the first and warn.
    """
    pattern = os.path.join(directory, f"{uid}*caca_heatmap.csv")
    matches = glob.glob(pattern)
    if not matches:
        return None
    if len(matches) > 1:
        warnings.warn(f"Multiple matches for {uid} in {directory}; using {matches[0]}")
    return matches[0]


def read_heatmap_csv(path: str) -> tuple[np.ndarray, list, list]:
    """Read CSV written by the heatmap scripts.

    Returns (matrix, row_labels, col_labels). Row/col labels are strings (1-based indices).
    """
    import csv

    with open(path, 'r', encoding='utf-8') as fh:
        reader = csv.reader(fh)
        rows = list(reader)

    if not rows:
        raise ValueError(f"Empty CSV: {path}")

    # Header: first cell empty, then column labels
    header = rows[0]
    col_labels = header[1:]

    data = []
    row_labels = []
    for r in rows[1:]:
        if not r:
            continue
        row_labels.append(r[0])
        # convert remaining entries to float (allow empty -> nan)
        vals = [float(x) if x != '' else np.nan for x in r[1:]]
        data.append(vals)

    mat = np.asarray(data, dtype=float)
    return mat, row_labels, col_labels


def write_csv_matrix(path: str, mat: np.ndarray, labels: list[str]):
    """Write matrix to CSV with 1-based labels in header and first column."""
    import csv

    n = mat.shape[0]
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        writer = csv.writer(fh)
        writer.writerow([''] + labels)
        for i in range(n):
            row = [labels[i]] + [f"{v:.6f}" for v in mat[i, :]]
            writer.writerow(row)


def plot_and_save_delta(mat_delta: np.ndarray, labels: list[str], out_png: str, title: str, cmap: str = 'RdBu_r', dpi: int = 300):
    import matplotlib.pyplot as plt

    vmax = float(np.nanmax(np.abs(mat_delta)))
    if np.isclose(vmax, 0.0):
        vmax = 1e-6

    fig, ax = plt.subplots(figsize=(6, 5), dpi=dpi)
    im = ax.imshow(mat_delta, origin='lower', cmap=cmap, interpolation='nearest', vmin=-vmax, vmax=vmax)
    # ticks: reduce to a small number (around 5) so tick labels can be larger for publication
    n = mat_delta.shape[0]
    nticks = 5
    step = max(1, n // nticks)
    ticks = list(range(0, n, step))
    ax.set_xticks(ticks)
    ax.set_yticks(ticks)
    ax.set_xticklabels([labels[i] for i in ticks], fontsize=14)
    ax.set_yticklabels([labels[i] for i in ticks], fontsize=14)

    # Remove axis labels for a cleaner figure (title retained)
    # ax.set_xlabel('Residue Number')
    # ax.set_ylabel('Residue Number')
    ax.set_title(title, fontsize=16)

    cbar = fig.colorbar(im, ax=ax)
    # Make colorbar ticks and label larger for readability
    try:
        cbar.ax.tick_params(labelsize=14)
        #cbar.set_label('Delta normalized distance (Ensemble - AF2)', fontsize=14)
    except Exception:
        pass

    ## Thicken spines and tick lines for a stronger plot outline
    #for spine in ax.spines.values():
    #    spine.set_linewidth(2.4)
    #    spine.set_edgecolor('black')
    #ax.tick_params(axis='both', which='both', width=1.8, length=6)

    plt.tight_layout()
    fig.savefig(out_png, dpi=dpi)
    plt.close(fig)


def main(argv=None):
    ap = argparse.ArgumentParser(description='Compare AF2 and ensemble CA-CA heatmap CSVs and produce delta heatmaps.')
    ap.add_argument('--ids', required=True, help='Path to file with one ID per line')
    ap.add_argument('--af2-dir', required=True, help='Directory with AF2 CSV heatmaps')
    ap.add_argument('--ens-dir', required=True, help='Directory with ensemble CSV heatmaps')
    ap.add_argument('-o', '--out-dir', required=True, help='Output directory for delta PNG/CSV')
    ap.add_argument('--cmap', default='RdBu_r', help='Colormap for delta plot (default RdBu_r)')
    ap.add_argument('--dpi', type=int, default=300, help='PNG DPI')
    args = ap.parse_args(argv)

    outp = Path(args.out_dir)
    outp.mkdir(parents=True, exist_ok=True)

    with open(args.ids, 'r', encoding='utf-8') as fh:
        ids = [line.strip() for line in fh if line.strip()]

    for uid in ids:
        af2_csv = find_csv_for_id(args.af2_dir, uid)
        ens_csv = find_csv_for_id(args.ens_dir, uid)
        if af2_csv is None:
            print(f"AF2 CSV not found for {uid}; skipping")
            continue
        if ens_csv is None:
            print(f"Ensemble CSV not found for {uid}; skipping")
            continue

        try:
            mat_af2, rows_af2, cols_af2 = read_heatmap_csv(af2_csv)
            mat_ens, rows_ens, cols_ens = read_heatmap_csv(ens_csv)
        except Exception as e:
            print(f"Failed reading CSVs for {uid}: {e}")
            continue

        if mat_af2.shape != mat_ens.shape:
            print(f"Shape mismatch for {uid}: AF2 {mat_af2.shape} vs ENS {mat_ens.shape}; skipping")
            continue

        # Optional: check labels match
        if rows_af2 != rows_ens or cols_af2 != cols_ens:
            warnings.warn(f"Label mismatch for {uid}; proceeding using numeric alignment")

        delta = mat_ens - mat_af2

        base = uid
        out_png = str(outp / f"{base}_delta_caca_heatmap.png")
        out_csv = str(outp / f"{base}_delta_caca_heatmap.csv")

        # labels to write: use rows_af2 (or generated 1..N if absent)
        n = delta.shape[0]
        if rows_af2 and len(rows_af2) == n:
            labels = rows_af2
        else:
            labels = [str(i + 1) for i in range(n)]

        # Save CSV
        try:
            write_csv_matrix(out_csv, delta, labels)
        except Exception as e:
            print(f"Warning: failed to write CSV for {uid}: {e}")

        # Plot
        try:
            plot_and_save_delta(delta, labels, out_png, title=f"ΔCα-Cα distance - {uid}", cmap=args.cmap, dpi=args.dpi)
            print(f"Wrote delta PNG/CSV for {uid}: {out_png}, {out_csv}")
        except Exception as e:
            print(f"Failed to create plot for {uid}: {e}")

    return 0


if __name__ == '__main__':
    raise SystemExit(main())
