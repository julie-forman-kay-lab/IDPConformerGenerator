'''
Build IDRs without folded domain.

REQUIREMENTS
------------
* IDPConformerGenerator v0.7.27
* OpenMM v8.2.0
* pdb-tools v2.5.0
* PDBFixer v1.9.0
* Database of IDR sequences

Date: August 6, 2025 (v2.0)
Author: Zi Hao Liu
'''
import re
import json
import os
import subprocess

from pdbfixer import PDBFixer
from glob import glob

from openmm.app import (
    PDBFile,
    ForceField,
    Simulation,
    HBonds,
    NoCutoff,
    )
from openmm import LangevinIntegrator, CustomExternalForce
from openmm.unit import *

from idpconfgen.libs.libmulticore import pool_function


# Change job parameters here.
# Set number will depend on the name of the script
nconfs = 100
ncores = 16
cc_ncores = 5  # OpenMM can't multiprocess with all cores
idrs_db_file = f"../databases/AlphaFlex_database_Jul2024.json"
idpcg_database = "../databases/idpconfgen_database.json"
set_num = int(re.search(r'\d+', sys.argv[0]).group())
output_directory = f"../AFX-IDPCG_IDR_ensembles/idr_set{set_num}"
idrs_id_file = f"../databases/idr_ids/idr{set_num}.txt"


def resolve_clash(pdb_file):
    """
    Inspired by Oliver Sun.
    
    Resolve clashes in the protein file through short md simulation steps while keeping
    protein backbone fixed during the process.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    pdb = PDBFile(pdb_file)
    forcefield = ForceField('amber99sb.xml')

    # Set up the OpenMM system
    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Select side-chain atoms by excluding backbone atoms
    sidechain_atoms = []
    for atom in pdb.topology.atoms():
            sidechain_atoms.append(atom.index)

    # Apply harmonic constraints to backbone atoms
    k = 10.0 * kilocalories_per_mole / angstrom**2  # Adjust this if needed
    constraint_force = CustomExternalForce('0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)')
    constraint_force.addPerParticleParameter('x0')
    constraint_force.addPerParticleParameter('y0')
    constraint_force.addPerParticleParameter('z0')
    constraint_force.addGlobalParameter('k', k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:  # Apply only to backbone atoms
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    # Set up the simulation
    integrator = LangevinIntegrator(300*kelvin, 1/picosecond, 0.002*picoseconds) # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)

    # Minimize energy (with constraints active)
    simulation.minimizeEnergy(maxIterations=1000)

    # Save the minimized structure
    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(f"{folder}/{name}_cr.pdb", 'w') as f:
        PDBFile.writeFile(simulation.topology, positions, f)
    
    os.remove(pdb_file)


def add_hydrogens(pdb_file, pH=7.4):
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)
    
    PDBFile.writeFile(
        fixer.topology,
        fixer.positions,
        open(f'{folder}/{name}_pro.pdb', 'w')
        )
    
    os.remove(pdb_file)


# Processing below
try:
    with open(idrs_db_file, 'r') as f:
        idrs_db = json.load(f)
    with open(idrs_id_file, 'r') as f:
        idrs_ids = [line.strip() for line in f]
except FileNotFoundError:
    print("Error: file not found for database, IDs, or max residues. Please check paths.")
    exit()

os.makedirs(output_directory, exist_ok=True)

for id in idrs_ids:
    # Set-up temporary directories
    path_final_ens = f"{output_directory}/{id}"
    os.makedirs(path_final_ens, exist_ok=True)
    idrs_to_make = idrs_db[id]["seqs"]

    for i, seq in enumerate(idrs_to_make):
        path_idr_ens = f"{path_final_ens}/{id}_seq{i+1}"
        os.makedirs(path_idr_ens, exist_ok=True)
        
        print(f"Building {nconfs} conformers for {id} sequence #{i + 1}...")
        
        num_res = len(seq)
        if num_res < 150:
            run_idpcg = subprocess.run(
                [f"idpconfgen build \
                    -seq {seq} \
                    -db {idpcg_database} \
                    --dloop-off --dany \
                    -nc {nconfs} -n {ncores} \
                    -of {path_idr_ens}"
                ],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )
        else:
            run_idpcg = subprocess.run(
                [f"idpconfgen build \
                    -seq {seq} \
                    -db {idpcg_database} \
                    --dloop-off --dany --long \
                    --force-long \
                    -nc {nconfs} -n {ncores} \
                    -of {path_idr_ens}"
                ],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )


        print("Adding hydrogens...")
        idpcg_files = glob(f"{path_idr_ens}/*.pdb")
        fix_atoms_pool = pool_function(add_hydrogens, idpcg_files, ncores=ncores)
        for _ in fix_atoms_pool:
            pass
        
        print("Resolving side-chain clashes...")
        hydrogenated_files = glob(f"{path_idr_ens}/*.pdb")
        cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
        for _ in cc_pool:
            pass

        # Make 100 PDBs as an ensemble file to save space
        run_pdbtools = subprocess.run(
                [f"pdb_mkensemble {path_idr_ens}/*.pdb > {path_idr_ens}/{id}_seq{i+1}_idpcg_n{nconfs}.pdb"],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )
        # Cleanup temporary files
        os.system(f"rm -rf {path_idr_ens}/conformer*")
        os.system(f"rm -rf {path_idr_ens}/temp*")
        os.system(f"rm -rf {path_idr_ens}/energies.log")
        print(f"Finished: {id} sequence {i+1}.")
