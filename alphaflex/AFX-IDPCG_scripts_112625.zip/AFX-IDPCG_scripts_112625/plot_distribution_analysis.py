import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


# Use a clean style without background grid lines
sns.set_style("white")

# Prepare data
data = [
    ['Rg (Å)', 0.0007, 'similar'],
    ['Rh (Å)', 0.0004, 'similar'],
    ['Ree (Å)', 0.0055, 'similar'],
    ['Asphericity', 0.0172, 'similar'],
    ['SASA (nm²)', 0.0000, 'similar'],
]

df = pd.DataFrame(data, columns=['Observable', 'JS-norm', 'Status'])

# Melt for seaborn
df_melt = df.melt(id_vars=['Observable', 'Status'], 
                  value_vars=['JS-norm'], 
                  var_name='Metric', value_name='Value')

# Plot
plt.figure(figsize=(6, 4), dpi=300)
ax = sns.barplot(data=df_melt, x='Observable', y='Value', hue='Metric',
                 palette='Set2', edgecolor='black', dodge=True)

# Ensure no grid lines are displayed
ax.grid(False)

# Make plot border spines black for consistency
for spine in ax.spines.values():
    spine.set_edgecolor('black')
    spine.set_linewidth(1.0)

# Add reference line for substantial difference threshold
ax.axhline(y=0.15, color='black', linestyle='--', linewidth=1.0)

# Remove legend
leg = ax.get_legend()
if leg is not None:
    leg.remove()

## Color status annotations
#for i, row in enumerate(df.itertuples()):
#    if row.Status == 'different':
#        plt.gca().get_xticklabels()[i].set_color('red')

#plt.title("Normalized Jensen-Shannon Divergence")
plt.ylabel("Normalized Jensen-Shannon Divergence Value")
plt.xlabel("")
plt.tight_layout()
plt.savefig("../analysis/comparison/js_divergence_comparison.png")
