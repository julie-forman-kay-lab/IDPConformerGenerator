'''
Analyzes structural versus sequence relationship data for AlphaFold structures.

Analysis can include calculated Rh (Å), Ree (Å), Rg (Å), Asphericity, SASA (Å²) against
sequence length, net charge, **sequence complexity, **charge and **aromatic patterning.

**Indicates analysis only done on the IDRs. Otherwise, for the whole sequence.

REQUIREMENTS
------------
* IDPConformerGenerator v0.7.25
* MDTraj v1.10.2

Date: Oct 30, 2025 (v1.0)
Author: Zi Hao Liu
'''
import math
import os
import json

import mdtraj as md
import numpy as np

from collections import Counter
from glob import glob
from idpconfgen.libs.libmulticore import pool_function

from hullrad import Sved, mesh_from_pdb


# Change parameters here
ensembles = glob("../FOLDER/*.pdb")
ensembles = [os.path.abspath(f) for f in ensembles]
output = "../FOLDER/ANALYSIS.json"
output_err = "../FOLDER/ERROR.json"
mesh = "../FOLDER/mesh.pdb"
ncores = 16

# Dictionary to convert 3-letter AA to 1-letter
aa_three_to_one = {
    "ALA": "A", "ARG": "R", "ASN": "N", "ASP": "D", "CYS": "C",
    "GLN": "Q", "GLU": "E", "GLY": "G", "HIS": "H", "ILE": "I",
    "LEU": "L", "LYS": "K", "MET": "M", "PHE": "F", "PRO": "P",
    "SER": "S", "THR": "T", "TRP": "W", "TYR": "Y", "VAL": "V",
    "SEC": "U", "PYL": "O", "ASX": "B", "GLX": "Z", "XLE": "J", "XAA": "X"
}
# pKa values for ionizable AA and terminal groups (source: Dr. Ian Hunt @ UCalgary)
pKa_values = {
    'D': 3.65,  # Aspartic acid
    'E': 4.25,  # Glutamic acid
    'H': 6.00,  # Histidine
    'C': 8.18,  # Cysteine
    'Y': 9.11, # Tyrosine
    'K': 10.53, # Lysine
    'R': 12.48, # Arginine
    'N_term': 7.95,  # N-terminal amine
    'C_term': 2.5   # C-terminal carboxyl
}


def wf_complexity_log20(sequence):
    # Count the occurrences of each amino acid
    amino_acid_counts = Counter(sequence)
    total_length = len(sequence)
    
    # Calculate the numerator: log(N! / (a!b!c!...))
    # Using log factorial to avoid large numbers and overflow
    log_n_factorial = math.lgamma(total_length + 1)  # log(N!)
    log_denominator = sum(math.lgamma(count + 1) for count in amino_acid_counts.values())  # log(a!b!c!...)
    log_numerator = log_n_factorial - log_denominator
    
    # Convert to log base 20
    log20_numerator = log_numerator / math.log(20)
    
    # Calculate the WF complexity
    wf_complexity = log20_numerator / total_length
    
    return wf_complexity


def sequence_charge_decoration(seq):
	scd=float(0)
	charge = {'D':-1,'E':-1, 'R':1,'K':1}
	positions=[]
	for i in range(1,len(seq)):
		if (seq[i] in charge):
				positions.append(i)
	for i in range(1,len(positions)):
		for j in range(0,i):
			scd+= float(charge[seq[positions[i]]]*charge[seq[positions[j]]])*math.sqrt(float(positions[i]-positions[j]))
	try:
		return scd/float(len(seq))
	except ZeroDivisionError:
		return np.nan


def my_aromspace(seq): #das and pappu suggest overlapping blobs of 5 or 6
	blob=5 ### my test is based on comparison of spacing between same charges.
	 ### if blob gets too small, then we are just capturing the repeats.
	aromatic = {'Y':1,'F':1, 'W':1}
	positions=[]
	tot= {1:0}
	dsame=[]
	for i in range (0,len(seq)):
		if (seq[i] in aromatic):
			if (len(positions)>0):
				dis = i - positions[-1]
				if (dis<=blob):
					if (aromatic[seq[i]] == aromatic[seq[positions[-1]]]):
						dsame.append(dis)
			positions.append(i)
			tot[aromatic[seq[i]]] += 1
	if (len(positions)>1):
		geompr = {  }
		sumpr=float(0)
		sumsq=float(0)
		for c in list(tot.keys()):
			geompr[c] = float(tot[c])/float(len(seq))
			sumpr += geompr[c]
		for c in list(tot.keys()):
			sumsq += geompr[c]*geompr[c]/sumpr
		prsame=float(0) ## use the bivariate geometric distribution to compute the probability of
					##finding two of the same within the a blob
		for d in range(0,blob):			#python's range is not including blob, so don't need the -1
			prsame += sumsq*(float(1)-sumpr)**d
		##use normal approx. to binomial
		if ((float(1)-prsame)*prsame >0):
			return (float(len(dsame)) - prsame*float(len(positions)))/math.sqrt((float(1)-prsame)*prsame*float(len(positions)))
		else:
			return(np.nan)
	else:
		return(np.nan)


def shannon_entropy(sequence):
    if not sequence:
        return 0.0
    
    counts = Counter(sequence)
    total_length = len(sequence)
    
    # Compute probabilities
    probabilities = np.array([count / total_length for count in counts.values()])
    
    # Compute Shannon entropy
    entropy = -np.sum(probabilities * np.log2(probabilities))
    
    return entropy


def net_charge(sequence, pH=7.4):
    """
    Compute the net charge of a protein sequence at a given pH.
    
    Parameters:
        sequence (str): Protein sequence (single-letter amino acid codes).
        pH (float): The pH at which to calculate the net charge.
    
    Returns:
        float: Net charge of the protein sequence.
    """
    if not sequence:
        return 0.0  # Return zero for empty sequences
    
    counts = Counter(sequence)
    charge = 0.0
    
    for res in ['K', 'R', 'H']:
        if res in pKa_values:
            charge += counts[res] * (1 / (1 + 10**(pH - pKa_values[res])))

    for res in ['D', 'E', 'C', 'Y']:
        if res in pKa_values:
            charge -= counts[res] * (1 / (1 + 10**(pKa_values[res] - pH)))
    
    # Terminal groups
    charge += 1 / (1 + 10**(pH - pKa_values['N_term']))  # N-terminal
    charge -= 1 / (1 + 10**(pKa_values['C_term'] - pH))  # C-terminal
    
    return charge


def hullrad_helper(pdb_path):
    try:
        """Return translational hydrodynamic radius given PDB."""
        filename = os.path.splitext(os.path.basename(pdb_path))[0]

        all_atm_rec, num_MG, num_MN, num_K, num_Na, model_array, mesh_coords, \
            tot_asa, prb_rad, elec_atm_rec = mesh_from_pdb(pdb_path)
        s, Dt, Dr, vbar_prot, Rht, ffo_hyd_P, M, Ro, Rhr, int_vis, a_b_ratio, Ft, \
            AnhRg, HydRg, Dmax, tauC, asphr, int_vis, tot_hydration, \
            vbar_hyd_prot, ks, TanfordBex, kd, AA, NA, GL, DT, useNumpy \
            = Sved(
                all_atm_rec,
                num_MG, num_MN,
                num_K, num_Na,
                model_array,
                mesh_coords,
                tot_asa,
                prb_rad, elec_atm_rec
                )

    except Exception as e:
        return 0, filename, f"Error: {e}"
    
    return Rht


def calc_struc_properties(pdb_path):
    try:
        name = os.path.basename(pdb_path)

        try:
            traj = md.load(pdb_path)
        except Exception as e:
            return name, f"Error: {e}"
        backbone_indices = traj.topology.select("protein")
        
        topology = traj.topology
        sequence = ""
        for chain in topology.chains:
            sequence += ''.join([residue.name for residue in chain.residues])
        
        # Converts 3 letter to 1 letter for sequence
        sequence = "".join(aa_three_to_one.get(sequence[i:i+3], "X") for i in range(0, len(sequence), 3))
        
        sequence_length = len(sequence)
        entropy = shannon_entropy(sequence)
        charge = net_charge(sequence)
        scd = sequence_charge_decoration(sequence)
        wf = wf_complexity_log20(sequence)
        arom = my_aromspace(sequence)
        

        for i, frame in enumerate(traj):
            backbone_frame = frame.atom_slice(backbone_indices)

            backbone_coords = backbone_frame.xyz[0]
            end_to_end_distance = np.linalg.norm(backbone_coords[0] - backbone_coords[-1])

            rg = md.compute_rg(backbone_frame)

            sasa = md.shrake_rupley(backbone_frame, probe_radius=0.14, mode='residue').sum()  # Sum over all residues

            inertia_tensor = md.geometry.compute_inertia_tensor(backbone_frame)
            eigenvalues = np.linalg.eigvalsh(inertia_tensor)
            asphericity = (eigenvalues.max() - eigenvalues.min()) / eigenvalues.sum()

            rg = rg[0] * 10

        rh = hullrad_helper(pdb_path)
    except Exception as e:
        return name, f"Error: {e}"
    
    return name, \
        end_to_end_distance, \
        rg, \
        asphericity, \
        sasa, \
        rh, \
        sequence_length, sequence, entropy, charge, wf, scd, arom


# Start of code logic
analysis_results = {}
analysis_errors = {}
calc_pool = pool_function(calc_struc_properties, ensembles, ncores=ncores)
for results in calc_pool:
    name = results[0]
    name = name.split(".")[0]
    if len(results) == 2:
        error = results[1]
        analysis_errors[name] = error
    else:
        ree = str(results[1])
        rg = str(results[2])
        a = str(results[3])
        sasa = str(results[4])
        rh = str(results[5])
        sequence_len = str(results[6])
        sequence = results[7]
        entropy = str(results[8])
        charge = str(results[9])
        wf = str(results[10])
        scd = str(results[11])
        arom = str(results[12])
        
        
        analysis_results[name] = {
            "Sequence": sequence,
            "Length": sequence_len,
            "Net Charge": charge,
            "SCD": scd,
            "Aromatic Kappa": arom,
            "Shannon-Entropy": entropy,
            "W-F Complexity": wf,
            "Rg": rg,
            "Rh": rh,
            "Ree": ree,
            "A": a,
            "SASA": sasa
            }
    
with open(output, 'w') as fout:
    json.dump(analysis_results, fout, indent=4)

with open(output_err, 'w') as fout:
    json.dump(analysis_errors, fout, indent=4)

os.remove(mesh)
