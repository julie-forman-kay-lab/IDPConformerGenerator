"""
Compare two analysis JSON files (AlphaFlex-style) and generate overlaid distribution
histograms for selected numeric properties (default: Rg, Rh, Ree, A, SASA).

Matching rule:
  Only include records whose (Sequence, Length) pair appears in BOTH JSON files.
  (Length is compared as an integer; Sequence must match exactly.)

For each property, the JSON value is expected to be either:
  - a list/tuple [value, stdev] (we take the first element), or
  - a single numeric (string or number) convertible to float.

Histograms:
  - Overlaid for file1 (blue, alpha=0.55) and file2 (orange, alpha=0.55)
  - Same bin edges for both datasets.
  - Number of bins adjustable via --bins (default 25)
  - Saved as PNG files into output directory, named <property>_hist.png

Missing / NaN values are skipped. If a property has <2 total points across both sets,
the plot is skipped (to reduce noise / empty plots).

Dependencies: matplotlib (seaborn optional). The script will fall back to pure
matplotlib if seaborn is unavailable.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
import math
import sys
from typing import Dict, Tuple, List, Any, Optional

import numpy as np


def load_json(path: str) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as fh:
        text = fh.read()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        repaired = re.sub(r',\s*(?=[}\]])', '', text)
        repaired = re.sub(r':\s*(NaN|nan|Infinity|-Infinity)', ': null', repaired)
        try:
            return json.loads(repaired)
        except json.JSONDecodeError as e:
            raise ValueError(f'Failed to parse JSON file {path}: {e}') from e


def coerce_float(val: Any):
    """Try to extract a primary numeric value from a JSON field.
    If val is list-like, return first element convertible to float.
    If val is str/number, convert directly.
    Return None if conversion fails or value is NaN.
    """
    try:
        if isinstance(val, (list, tuple)) and val:
            val0 = val[0]
        else:
            val0 = val
        f = float(val0)
        if math.isnan(f):
            return None
        return f
    except Exception:
        return None


def build_index(data: Dict[str, Any]) -> Dict[Tuple[str, int], List[Dict[str, Any]]]:
    """Return mapping from (Sequence, Length) to list of entry dicts (allowing duplicates).
    Length is coerced to int if possible; entries without valid sequence/length skipped.
    """
    idx: Dict[Tuple[str, int], List[Dict[str, Any]]] = {}
    for key, record in data.items():
        if not isinstance(record, dict):
            continue
        seq = record.get('Sequence')
        length_raw = record.get('Length')
        if seq is None or length_raw is None:
            continue
        try:
            length_int = int(str(length_raw))
        except Exception:
            continue
        idx.setdefault((seq, length_int), []).append(record)
    return idx


def aggregate_values(records: List[Dict[str, Any]], prop: str) -> Tuple[List[float], int]:
    values: List[float] = []
    missing = 0
    for r in records:
        if prop not in r:
            missing += 1
            continue
        f = coerce_float(r[prop])
        if f is None:
            missing += 1
            continue
        values.append(f)
    return values, missing


def collect_distributions(idx1, idx2, properties: List[str]):
    """Return (dists, common_count, missing_info).

    dists[prop] -> (list1, list2)
    missing_info[prop] -> {
        'file1_missing': count,
        'file2_missing': count,
        'file1_total': total entries considered,
        'file2_total': total entries considered,
    }
    """
    result = {}
    missing_info: Dict[str, Dict[str, int]] = {}
    common_keys = set(idx1.keys()) & set(idx2.keys())
    for prop in properties:
        vals1: List[float] = []
        vals2: List[float] = []
        miss1_total = 0
        miss2_total = 0
        tot1 = 0
        tot2 = 0
        for k in common_keys:
            records1 = idx1[k]
            records2 = idx2[k]
            if not records1 or not records2:
                continue
            paired_count = min(len(records1), len(records2))
            if paired_count <= 0:
                continue
            records1_trim = records1[:paired_count]
            records2_trim = records2[:paired_count]
            v1, m1 = aggregate_values(records1_trim, prop)
            v2, m2 = aggregate_values(records2_trim, prop)
            vals1.extend(v1)
            vals2.extend(v2)
            miss1_total += m1
            miss2_total += m2
            tot1 += len(records1_trim)
            tot2 += len(records2_trim)
        if len(vals1) != len(vals2):
            common_len = min(len(vals1), len(vals2))
            if common_len > 0:
                vals1 = vals1[:common_len]
                vals2 = vals2[:common_len]
            else:
                vals1 = []
                vals2 = []
        result[prop] = (vals1, vals2)
        missing_info[prop] = {
            'file1_missing': miss1_total,
            'file2_missing': miss2_total,
            'file1_total': tot1,
            'file2_total': tot2,
        }
    return result, len(common_keys), missing_info


def compute_bin_edges(values: List[float], bins: int, bin_width: Optional[float]) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    vmin = float(np.min(arr))
    vmax = float(np.max(arr))

    if np.isclose(vmin, vmax):
        if bin_width and bin_width > 0:
            half = bin_width / 2.0
        else:
            half = max(abs(vmin) * 0.05, 0.5)
        return np.array([vmin - half, vmin + half], dtype=float)

    if bin_width and bin_width > 0:
        start = math.floor(vmin / bin_width) * bin_width
        end = math.ceil(vmax / bin_width) * bin_width
        if end <= start:
            end = start + bin_width
        # ensure inclusion of end by extending slightly
        edges = np.arange(start, end + bin_width * 1.5, bin_width, dtype=float)
        if len(edges) < 2:
            edges = np.array([start, start + bin_width], dtype=float)
        return edges

    count = max(1, bins)
    return np.linspace(vmin, vmax, count + 1, dtype=float)


def compute_histograms(vals1: List[float], vals2: List[float], bins: int, bin_width: Optional[float]):
    combined = vals1 + vals2
    if len(combined) == 0:
        return None
    edges = compute_bin_edges(combined, bins=bins, bin_width=bin_width)
    hist1, _ = np.histogram(vals1, bins=edges)
    hist2, _ = np.histogram(vals2, bins=edges)
    return edges, hist1, hist2


def compute_kl_metrics(hist1: np.ndarray, hist2: np.ndarray) -> Dict[str, Optional[float]]:
    """Return KL and Jensen–Shannon divergences.

    Jensen–Shannon divergence (JSD) is bounded in [0, ln 2] when using natural
    logarithms (Lin, 1991; Endres & Schindelin, 2003). We normalise by ln 2 to
    map the value into [0, 1], and additionally report the Jensen–Shannon
    distance sqrt(JSD / ln 2) as recommended by Fuglede & Topsøe (2004).
    """
    p = hist1.astype(float)
    q = hist2.astype(float)
    if p.sum() == 0 or q.sum() == 0:
        return {'kl12': None, 'kl21': None, 'js': None, 'js_norm': None, 'js_dist': None}
    eps = 1e-12
    p = p + eps
    q = q + eps
    p /= p.sum()
    q /= q.sum()
    kl12 = float(np.sum(p * np.log(p / q)))
    kl21 = float(np.sum(q * np.log(q / p)))
    m = 0.5 * (p + q)
    js = float(0.5 * np.sum(p * np.log(p / m)) + 0.5 * np.sum(q * np.log(q / m)))
    norm = float(js / math.log(2.0)) if js is not None else None
    js_distance = float(math.sqrt(norm)) if norm is not None else None
    return {'kl12': kl12, 'kl21': kl21, 'js': js, 'js_norm': norm, 'js_dist': js_distance}


def plot_histograms(
    dists: Dict[str, Tuple[List[float], List[float]]],
    outdir: str,
    bins: int,
    bin_width: Optional[float],
    bin_width_map: Dict[str, float],
    label1: str,
    label2: str,
    dpi: int = 300,
):
    """Create overlaid histograms for each property in dists and save as PNG.
    dists: mapping property -> (list1, list2)
    """
    outp = Path(outdir)
    outp.mkdir(parents=True, exist_ok=True)

    # Optional seaborn styling
    seaborn_loaded = False
    try:
        import seaborn as sns  # type: ignore
        seaborn_loaded = True
        sns.set_context('notebook')
        sns.set_style('whitegrid')
    except Exception:
        pass

    import matplotlib.pyplot as plt  # local import to allow headless environments until needed

    hist_results = {}
    for prop, (vals1, vals2) in dists.items():
        total = len(vals1) + len(vals2)
        if total < 2:
            # skip trivial distributions
            continue
        effective_width = bin_width_map.get(prop, bin_width)
        hist_data = compute_histograms(vals1, vals2, bins=bins, bin_width=effective_width)
        if hist_data is None:
            continue
        edges, hist1, hist2 = hist_data
        fig, ax = plt.subplots(figsize=(6,4), dpi=dpi)
        color1 = '#1f77b4'  # blue
        color2 = '#ff7f0e'  # orange
        #ax.hist(vals1, bins=edges, color=color1, alpha=0.55, label=f'{label1} (n={len(vals1)})')
        #ax.hist(vals2, bins=edges, color=color2, alpha=0.55, label=f'{label2} (n={len(vals2)})')
        ax.hist(vals1, bins=edges, color=color1, alpha=0.55, label=f'{label1}', edgecolor='black', linewidth=0.6)
        ax.hist(vals2, bins=edges, color=color2, alpha=0.55, label=f'{label2}', edgecolor='black', linewidth=0.6)
        # Set axis spines (plot borders) to black for clearer framing
        for spine in ax.spines.values():
            spine.set_edgecolor('black')
            spine.set_linewidth(1.0)
        if prop == "A":
            prop = "Asphericity"
        elif prop == "Ree":
            prop = "End-to-end Distance Å"
        elif prop == "Rg":
            prop = "Radius of Gyration Å"
        elif prop == "Rh":
            prop = "Hydrodynamic Radius Å"
        elif prop == "SASA":
            prop = "Solvent Accessible Surface Area nm²"
        ax.set_xlabel(prop)
        ax.set_ylabel('Count')
        ax.grid(False)
        # Ensure tick marks and labels are visible and styled
        ax.tick_params(axis='both', which='both', direction='out', length=4, width=1.0, color='black', labelcolor='black')
        ax.xaxis.set_ticks_position('bottom')
        ax.yaxis.set_ticks_position('left')
        #ax.set_title(f'Distribution of {prop}')
        ax.legend()
        fig.tight_layout()
        outfile = outp / f'{prop}_hist.png'
        fig.savefig(outfile)
        plt.close(fig)
        hist_results[prop] = {'edges': edges, 'hist1': hist1, 'hist2': hist2}

    return hist_results


def summarize(dists: Dict[str, Tuple[List[float], List[float]]]) -> str:
    lines = []
    for prop, (v1, v2) in dists.items():
        if not v1 and not v2:
            continue
        def stats(vals):
            if not vals:
                return 'n=0'
            import statistics as st
            try:
                return f"n={len(vals)} mean={st.fmean(vals):.3f} sd={st.pstdev(vals):.3f}"
            except Exception:
                return f"n={len(vals)}"
        lines.append(f"{prop}: file1 {stats(v1)} | file2 {stats(v2)}")
    return '\n'.join(lines)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description='Compare two analysis JSON files and plot overlaid distributions for selected properties.')
    ap.add_argument('json1', help='First analysis JSON file')
    ap.add_argument('json2', help='Second analysis JSON file')
    ap.add_argument('-o', '--outdir', required=True, help='Output directory for plots')
    ap.add_argument('--properties', nargs='*', default=['Rg', 'Rh', 'Ree', 'A', 'SASA'], help='Properties to compare (default: Rg Rh Ree A SASA)')
    ap.add_argument('--bins', type=int, default=25, help='Number of histogram bins (default 25)')
    ap.add_argument('--bin-width', type=float, default=None, help='Explicit bin width (overrides --bins when provided)')
    ap.add_argument('--bin-width-map', nargs='*', default=['Rg=1', 'Rh=1', 'Ree=1', 'A=0.01', 'SASA=20'], metavar='PROP=WIDTH', help='Per-property bin width overrides, e.g., Rg=10 Rh=5')
    ap.add_argument('--label1', default='File1', help='Legend label for first JSON')
    ap.add_argument('--label2', default='File2', help='Legend label for second JSON')
    ap.add_argument('--min-common', type=int, default=1, help='Minimum number of matching (Sequence, Length) pairs required to proceed (default 1)')
    ap.add_argument('--no-kl', action='store_true', help='Skip KL / JS divergence calculations')
    ap.add_argument('--js-threshold', type=float, default=0.15,
                    help='Threshold on normalized Jensen–Shannon divergence (0-1) above which distributions are flagged as different (default 0.15).')
    args = ap.parse_args(argv)

    prop_bin_map: Dict[str, float] = {}
    for item in args.bin_width_map:
        if '=' not in item:
            ap.error(f"Invalid --bin-width-map entry '{item}'. Use PROP=WIDTH format.")
        prop, val = item.split('=', 1)
        prop = prop.strip()
        try:
            width = float(val)
        except ValueError:
            ap.error(f"Invalid bin width '{val}' for property '{prop}'.")
        if width <= 0:
            ap.error(f"Bin width must be positive for property '{prop}'.")
        prop_bin_map[prop] = width
    args.bin_width_map = prop_bin_map
    return args


def main(argv=None):
    args = parse_args(argv)
    if args.bin_width is not None and args.bin_width <= 0:
        raise SystemExit('Error: --bin-width must be positive when supplied')
    try:
        data1 = load_json(args.json1)
    except ValueError as e:
        print(e)
        return 1
    try:
        data2 = load_json(args.json2)
    except ValueError as e:
        print(e)
        return 1
    idx1 = build_index(data1)
    idx2 = build_index(data2)

    dists, common, missing_info = collect_distributions(idx1, idx2, args.properties)
    if common < args.min_common:
        print(f'Only found {common} matching (Sequence, Length) pairs (< {args.min_common}); aborting.')
        return 1

    hist_results = plot_histograms(
        dists,
        args.outdir,
        bins=args.bins,
        bin_width=args.bin_width,
        bin_width_map=args.bin_width_map,
        label1=args.label1,
        label2=args.label2,
    )
    summary_lines: List[str] = []
    summary_lines.append('Summary stats:')
    summary_body = summarize(dists)
    if summary_body:
        summary_lines.append(summary_body)
    else:
        summary_lines.append('  (no values to summarize)')
    # Report excluded entries
    summary_lines.append('')
    summary_lines.append('Excluded entries (missing or non-numeric):')
    any_missing_reported = False
    for prop, info in missing_info.items():
        tot1 = info['file1_total']
        tot2 = info['file2_total']
        miss1 = info['file1_missing']
        miss2 = info['file2_missing']
        if tot1 == 0 and tot2 == 0:
            continue
        any_missing_reported = True
        pct1 = 0.0 if tot1 == 0 else (miss1 / tot1 * 100.0)
        pct2 = 0.0 if tot2 == 0 else (miss2 / tot2 * 100.0)
        summary_lines.append(
            f"  {prop}: File1 missing={miss1}/{tot1} ({pct1:.1f}%), File2 missing={miss2}/{tot2} ({pct2:.1f}%)"
        )
    if not any_missing_reported:
        summary_lines.append('  none')

    if not args.no_kl:
        summary_lines.append('')
        summary_lines.append('Divergence metrics (KL file1||file2, KL file2||file1, Jensen-Shannon, normalized JS ∈ [0,1]):')
        for prop, info in hist_results.items():
            metrics = compute_kl_metrics(info['hist1'], info['hist2'])
            kl12 = metrics['kl12']
            kl21 = metrics['kl21']
            js = metrics['js']
            js_norm = metrics['js_norm']
            js_dist = metrics['js_dist']
            def fmt(val):
                return 'n/a' if val is None else f'{val:.4f}'
            status = 'different' if (js_norm is not None and js_norm >= args.js_threshold) else 'similar'
            js_norm_str = fmt(js_norm)
            js_dist_str = fmt(js_dist)
            summary_lines.append(
                f"  {prop}: KL12={fmt(kl12)} KL21={fmt(kl21)} JS={fmt(js)} JS_dist={js_dist_str} JS_norm={js_norm_str} status={status}"
            )
    summary_lines.append(f'Plots saved to {args.outdir}')

    summary_text = '\n'.join(summary_lines)
    print(summary_text)

    summary_path = Path(args.outdir) / 'summary.txt'
    try:
        with open(summary_path, 'w', encoding='utf-8') as fh:
            fh.write(summary_text + '\n')
    except Exception as e:
        print(f'Warning: failed to write summary to {summary_path}: {e}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
