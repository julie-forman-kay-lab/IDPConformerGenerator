'''
Main builder function for easy slow cases (N-IDR, C-IDR).

Number of IDR residues exceed 150 AA.

REQUIREMENTS
------------
* IDPConformerGenerator v0.7.27
* OpenMM v8.2.0
* pdb-tools v2.5.0
* PDBFixer v1.9.0
* Master database, IDs to process, folder of AF2-PDBs as templates

Date: March 20, 2025 (v5.1)
Author: Zi Hao Liu
'''
import re
import sys
import json
import os
import subprocess
import random

import numpy as np

from functools import partial
from pdbfixer import PDBFixer
from glob import glob

from openmm.app import (
    PDBFile,
    ForceField,
    Simulation,
    HBonds,
    NoCutoff,
    )
from openmm import LangevinIntegrator, CustomExternalForce
from openmm.unit import *

from idpconfgen import Path
from idpconfgen.libs.libstructure import (
    Structure,
    col_resSeq,
    col_name,
    cols_coords,
    col_chainID,
    col_serial,
    structure_to_pdb,
    write_PDB,
    parse_pdb_to_array,
    )
from idpconfgen.ldrs_helper import (
    disorder_cases,
    align_coords,
    count_clashes,
    )
from idpconfgen.libs.libmulticore import pool_function


# Change job parameters here.
# Set number will depend on the name of the script
set_num = int(re.search(r'\d+', sys.argv[0]).group())  
nconfs = 100
ncores = 16
cc_ncores = 10  # Will use up a lot of resources, keep this small
output_directory = f"../AFX_Category1/Category1_ens{set_num}"
easy_ids_file = f"../databases/Category1_IDs/ID{set_num}.txt"
idpcg_database = "../databases/idpconfgen_database.json"
master_db_file = "../databases/AlphaFlex_database_Jul2024.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
af2_pdbs = glob("../databases/AF2_9606_PDB/*.pdb")


def resolve_clash(pdb_file):
    """
    Inspired by Oliver Sun.
    
    Resolve clashes in the protein file through short md simulation steps while keeping
    protein backbone fixed during the process.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    pdb = PDBFile(pdb_file)
    forcefield = ForceField('amber99sb.xml')

    # Set up the OpenMM system
    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Select side-chain atoms by excluding backbone atoms
    sidechain_atoms = []
    for atom in pdb.topology.atoms():
        if atom.name not in ['N', 'CA', 'C', 'O']:  # Backbone atoms
            sidechain_atoms.append(atom.index)

    # Apply harmonic constraints to backbone atoms
    k = 10.0 * kilocalories_per_mole / angstrom**2  # Adjust this if needed
    constraint_force = CustomExternalForce('0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)')
    constraint_force.addPerParticleParameter('x0')
    constraint_force.addPerParticleParameter('y0')
    constraint_force.addPerParticleParameter('z0')
    constraint_force.addGlobalParameter('k', k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:  # Apply only to backbone atoms
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    # Set up the simulation
    integrator = LangevinIntegrator(300*kelvin, 1/picosecond, 0.002*picoseconds) # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)

    # Minimize energy (with constraints active)
    simulation.minimizeEnergy(maxIterations=1000)

    # Save the minimized structure
    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(f"{folder}/{name}_cr.pdb", 'w') as f:
        PDBFile.writeFile(simulation.topology, positions, f)
    
    os.remove(pdb_file)


def add_hydrogens(pdb_file, pH=7.4):
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)
    
    PDBFile.writeFile(
        fixer.topology,
        fixer.positions,
        open(f'{folder}/{name}_pro.pdb', 'w')
        )
    
    os.remove(pdb_file)


def idr_aligner(idr, fld_struc, case, rs, output):
    # Folded structure should already be built
    fld_name = fld_struc.data_array[:, col_name]
    fld_seq = fld_struc.data_array[:, col_resSeq].astype(int)
    
    first_seq = fld_seq[0]
    last_seq = fld_seq[-1]
    
    fld_term_idx = {}
    if case == "N-IDR":
        for j, atom in enumerate(fld_name):
            curr_seq = fld_seq[j]
            if curr_seq == first_seq + 1 and atom == "N":
                fld_term_idx["N"] = j
            elif curr_seq == first_seq + 1 and atom == "CA":
                fld_term_idx["CA"] = j
            elif curr_seq == first_seq and atom == "C":
                fld_term_idx["C"] = j
            elif curr_seq == first_seq + 2:
                break
    elif case == "C-IDR":
        for j, _atom in enumerate(fld_name):
            k = len(fld_name) - 1 - j
            curr_seq = fld_seq[k]
            if curr_seq == last_seq and fld_name[k] == "N":
                fld_term_idx["N"] = k
            elif curr_seq == last_seq and fld_name[k] == "CA":
                fld_term_idx["CA"] = k
            elif curr_seq == last_seq - 1 and fld_name[k] == "C":
                fld_term_idx["C"] = k
            elif curr_seq == last_seq - 2:
                break

    fld_Cxyz = fld_struc.data_array[fld_term_idx["C"]][cols_coords].astype(float)  # noqa: E501
    fld_Nxyz = fld_struc.data_array[fld_term_idx["N"]][cols_coords].astype(float)  # noqa: E501
    fld_CAxyz = fld_struc.data_array[fld_term_idx["CA"]][cols_coords].astype(float)  # noqa: E501
    # Coordinates of boundary to stitch to later on
    fld_coords = np.array([fld_Cxyz, fld_Nxyz, fld_CAxyz])
    
    with open(idr) as f:
        idr_data = f.read()
    try:
        idr_arr = parse_pdb_to_array(idr_data)
    except AssertionError:
        return
    
    aligned_idr = align_coords(idr_arr, fld_coords, case)
    clashes, fragment = count_clashes(
        aligned_idr,
        fld_struc,
        case,
        max_clash=80,
        tolerance=0.4
        )
    if type(clashes) is int:
        aligned_struc = structure_to_pdb(fragment)
        idr_split = idr.split("/")
        idr_int = int(re.search(r'\d+', idr_split[-1]).group())
        write_PDB(aligned_struc, output + f"/aligned_{case}_rs{rs}_{idr_int}.pdb")


def idr_stitcher(idr_arr, case, fld_arr, output, idx):
    chain = fld_arr[:, col_chainID][0]
    seq_fld = fld_arr[:, col_resSeq]
    last_seq_fld = int(seq_fld[-1])
    
    if len(case) == 1:  # N-IDR or C-IDR
        seq_idr = idr_arr[:, col_resSeq]
        # correct chain ID
        for i, _ in enumerate(idr_arr):
            idr_arr[i][col_chainID] = chain
        
        if case[0] == disorder_cases[0]:  # remove last residue on N-IDR
            for i, _ in enumerate(seq_idr):
                j = len(seq_idr) - 1 - i
                curr = seq_idr[j]
                prev = seq_idr[j - 1]
                idr_arr = idr_arr[:-1]
                if prev != curr:
                    break
            # remove first residue on folded protein
            for i, seq in enumerate(seq_fld):
                next = seq_fld[i + 1]
                fld_arr = fld_arr[1:]
                if next != seq:
                    break
            
            fld_lst = fld_arr.tolist()
            idr_lst = idr_arr.tolist()
            new_struc_lst = idr_lst + fld_lst
        else:  # remove first resique on C-IDR
            for i, seq in enumerate(seq_idr):
                next = seq_idr[i + 1]
                idr_arr = idr_arr[1:]
                if next != seq:
                    break
            # remove last residue on folded protein
            for i, _ in enumerate(seq_fld):
                j = len(seq_fld) - 1 - i
                curr = seq_fld[j]
                prev = seq_fld[j - 1]
                fld_arr = fld_arr[:-1]
                if prev != curr:
                    break
            # correct residue numberings for C-IDR
            for i, line in enumerate(idr_arr):
                resnum = int(line[col_resSeq])
                idr_arr[i][col_resSeq] = str(resnum + last_seq_fld - 2)
            
            fld_lst = fld_arr.tolist()
            idr_lst = idr_arr.tolist()
            new_struc_lst = fld_lst + idr_lst
        
        new_struc_arr = np.array(new_struc_lst)
    else:  # Both IDRs
        nidr_path = idr_arr[0]
        cidr_path = idr_arr[1]
        nidr_struc = Structure(Path(nidr_path))
        cidr_struc = Structure(Path(cidr_path))
        nidr_struc.build()
        cidr_struc.build()
        nidr_arr = nidr_struc.data_array
        cidr_arr = cidr_struc.data_array
        
        seq_nidr = nidr_arr[:, col_resSeq]
        seq_cidr = cidr_arr[:, col_resSeq]
        
        # correct chain ID
        for i, _ in enumerate(nidr_arr):
            nidr_arr[i][col_chainID] = chain
        for i, _ in enumerate(cidr_arr):
            cidr_arr[i][col_chainID] = chain
        
        # remove last residue on nidr
        for i, _ in enumerate(seq_nidr):
            j = len(seq_nidr) - 1 - i
            curr = seq_nidr[j]
            prev = seq_nidr[j - 1]
            nidr_arr = nidr_arr[:-1]
            if prev != curr:
                break
        # remove first residue on folded protein
        for i, seq in enumerate(seq_fld):
            next = seq_fld[i + 1]
            fld_arr = fld_arr[1:]
            if next != seq:
                break
        # remove first residue on cidr
        for i, seq in enumerate(seq_cidr):
            next = seq_cidr[i + 1]
            cidr_arr = cidr_arr[1:]
            if next != seq:
                break
        # remove last residue on folded protein
        for i, _ in enumerate(seq_fld):
            j = len(seq_fld) - 1 - i
            curr = seq_fld[j]
            prev = seq_fld[j - 1]
            fld_arr = fld_arr[:-1]
            if prev != curr:
                break
        # correct residue numberings for C-IDR
        for i, line in enumerate(cidr_arr):
            resnum = int(line[col_resSeq])
            cidr_arr[i][col_resSeq] = str(resnum + last_seq_fld - 2)
        
        fld_lst = fld_arr.tolist()
        nidr_lst = nidr_arr.tolist()
        cidr_lst = cidr_arr.tolist()
        new_struc_lst = nidr_lst + fld_lst + cidr_lst
        new_struc_arr = np.array(new_struc_lst)
    
    new_serial = [str(i) for i in range(1, len(new_struc_arr) + 1)]
    new_struc_arr[:, col_serial] = new_serial
    new_struc = structure_to_pdb(new_struc_arr)
    
    write_PDB(new_struc, output + f"/conformer_{idx}.pdb")


def combo_clash_checker(nidrs, cidrs):
    # List of NIDR and CIDR array combinations in tuples
    combinations = []
    
    # ensure we have the same amount of things in each list
    nidrs = nidrs[:100]
    cidrs = cidrs[:100]
    while len(combinations) < 100:
        random.shuffle(nidrs)
        random.shuffle(cidrs)
        temp_combinations = list(zip(nidrs, cidrs))
        
        for c in temp_combinations:
            nidr_struc = Structure(Path(c[0]))
            cidr_struc = Structure(Path(c[1]))
            nidr_struc.build()
            cidr_struc.build()

            nc, _ = count_clashes(nidr_struc.data_array, cidr_struc)
            if type(nc) is bool:
                continue
            else:
                combinations.append(c)

    combinations = combinations[:100]
    return combinations


# Processing below
try:
    with open(master_db_file, 'r') as f:
        master_db = json.load(f)
    with open(easy_ids_file, 'r') as f:
        easy_ids = [line.strip() for line in f]
    with open(max_residues_file, 'r') as f:
        max_residues = json.load(f)
except FileNotFoundError:
    print("Error: file not found for database, IDs, or max residues. Please check paths.")
    exit()

# Checks for output directory
if not os.path.exists(output_directory):
    os.mkdir(output_directory)

for id in easy_ids:
    # Set-up temporary directories
    path_final_ens = f"{output_directory}/{id}"
    path_templates = f"{path_final_ens}/temp_templates"
    path_idrs = f"{path_final_ens}/temp_idrs"
    if not os.path.exists(path_final_ens):
        os.mkdir(path_final_ens)
    if not os.path.exists(path_templates):
        os.mkdir(path_templates)
    if not os.path.exists(path_idrs):
        os.mkdir(path_idrs)

    # Find entries in database
    pdb_path = [p for p in af2_pdbs if id in p][0]
    struc = Structure(Path(pdb_path))
    struc.build()
    sequence = next(iter(struc.fasta.values()))
    details = master_db[id]['idrs']
    num_res = max_residues[id]

    print(f"Building {nconfs} conformers for {id}...")
    
    case = []
    if len(details) == 1 and details[0][0] == 1 and details[0][1] == num_res:  # IDP case
        run_idpcg = subprocess.run(
                [f"idpconfgen build \
                    -seq {sequence} \
                    -db {idpcg_database} \
                    --dloop-off --dany --long \
                    -nc {nconfs} -n {ncores} \
                    -of {path_final_ens}"
                ],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )
    else:
        struc_arr = struc.data_array
        seqs = struc.data_array[:, col_resSeq].astype(int)
        seq_mask = np.ones(seqs.shape, dtype=bool)
        for start, end, in details:
            seq_mask[(seqs >= start) & (seqs <= end)] = False
        filtered_struc_arr = struc_arr[seq_mask]
        template_struc = structure_to_pdb(filtered_struc_arr)
        output_template_path = path_templates + f"/{id}_processed.pdb"

        write_PDB(template_struc, output_template_path)

        af2_template = Structure(Path(output_template_path))
        af2_template.build()
        
        if len(details) == 1 and details[0][0] == 1:  # N-IDR only case
            case.append(disorder_cases[0])
            sequence = sequence[:details[0][1] + 2]
            path_nidrs = path_idrs + f"/{disorder_cases[0]}"
            path_nidrs_passed = path_idrs + f"/{disorder_cases[0]}_passed"
            os.mkdir(path_nidrs)
            os.mkdir(path_nidrs_passed)

            rs = 0
            num_nidrs_passed = 0
            while num_nidrs_passed < 100:
                run_idpcg = subprocess.run(
                    [f"idpconfgen build \
                        -seq {sequence} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -nc {nconfs * 2} -n {ncores} \
                        -rs {rs} --long --force-long \
                        -of {path_nidrs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
                nidr_lst = glob(f"{path_nidrs}/*.pdb")
                execute = partial(
                    idr_aligner,
                    fld_struc=af2_template,
                    case=disorder_cases[0],
                    rs=rs,
                    output=path_nidrs_passed
                    )
                execute_pool = pool_function(execute, nidr_lst, ncores=ncores)
                print(f"Aligning N-IDRs for {id}...")
                for _ in execute_pool:
                    pass
                rs += ncores
                nidrs_passed = glob(f"{path_nidrs_passed}/*.pdb")
                num_nidrs_passed = len(nidrs_passed)

            for i in range(1, nconfs + 1):
                sample_nidr = nidrs_passed[i - 1]
                nidr_struc = Structure(Path(sample_nidr))
                nidr_struc.build()

                idr_stitcher(
                    idr_arr=nidr_struc.data_array,
                    case=case,
                    fld_arr=af2_template.data_array,
                    output=path_final_ens,
                    idx=i,
                    )

        elif len(details) == 1 and details[0][1] == num_res:  # C-IDR only case
            case.append(disorder_cases[2])
            sequence = sequence[details[0][0] - 3:]
            path_cidrs = path_idrs + f"/{disorder_cases[2]}"
            path_cidrs_passed = path_idrs + f"/{disorder_cases[2]}_passed"
            os.mkdir(path_cidrs)
            os.mkdir(path_cidrs_passed)

            rs = 0
            num_cidrs_passed = 0
            while num_cidrs_passed < 100:
                run_idpcg = subprocess.run(
                    [f"idpconfgen build \
                        -seq {sequence} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -nc {nconfs * 2} -n {ncores} \
                        -rs {rs} --long --force-long \
                        -of {path_cidrs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
                cidr_lst = glob(f"{path_cidrs}/*.pdb")
                execute = partial(
                    idr_aligner,
                    fld_struc=af2_template,
                    case=disorder_cases[2],
                    rs=rs,
                    output=path_cidrs_passed
                    )
                execute_pool = pool_function(execute, cidr_lst, ncores=ncores)
                print(f"Aligning C-IDRs for {id}...")
                for _ in execute_pool:
                    pass
                rs += ncores
                cidrs_passed = glob(f"{path_cidrs_passed}/*.pdb")
                num_cidrs_passed = len(cidrs_passed)

            for i in range(1, nconfs + 1):
                sample_cidr = cidrs_passed[i - 1]
                cidr_struc = Structure(Path(sample_cidr))
                cidr_struc.build()

                idr_stitcher(
                    idr_arr=cidr_struc.data_array,
                    case=case,
                    fld_arr=af2_template.data_array,
                    output=path_final_ens,
                    idx=i,
                    )

        else:  # Both N-IDR and C-IDR case
            case.append(disorder_cases[0])
            case.append(disorder_cases[2])
            nidr_seq = sequence[:details[0][1] + 2]
            cidr_seq = sequence[details[1][0] - 3:]
            path_nidrs = path_idrs + f"/{disorder_cases[0]}"
            os.mkdir(path_nidrs)
            path_cidrs = path_idrs + f"/{disorder_cases[2]}"
            os.mkdir(path_cidrs)
            path_nidrs_passed = path_idrs + f"/{disorder_cases[0]}_passed"
            os.mkdir(path_nidrs_passed)
            path_cidrs_passed = path_idrs + f"/{disorder_cases[2]}_passed"
            os.mkdir(path_cidrs_passed)

            rs = 0
            num_nidrs_passed = 0
            while num_nidrs_passed < 100:
                run_idpcg_nidrs = subprocess.run(
                    [f"idpconfgen build \
                        -seq {nidr_seq} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -nc {nconfs * 2} -n {ncores} \
                        -rs {rs} --long --force-long \
                        -of {path_nidrs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
                nidr_lst = glob(f"{path_nidrs}/*.pdb")
                execute = partial(
                    idr_aligner,
                    fld_struc=af2_template,
                    case=disorder_cases[0],
                    rs=rs,
                    output=path_nidrs_passed
                    )
                execute_pool = pool_function(execute, nidr_lst, ncores=ncores)
                print(f"Aligning N-IDRs for {id}...")
                for _ in execute_pool:
                    pass
                rs += ncores
                nidrs_passed = glob(f"{path_nidrs_passed}/*.pdb")
                num_nidrs_passed = len(nidrs_passed)

            rs = 0
            num_cidrs_passed = 0
            while num_cidrs_passed < 100:
                run_idpcg_cidrs = subprocess.run(
                    [f"idpconfgen build \
                        -seq {cidr_seq} \
                        -db {idpcg_database} \
                        --dloop-off --dany \
                        -nc {nconfs * 2} -n {ncores} \
                        -rs {rs} --long --force-long \
                        -of {path_cidrs}"
                    ],
                    capture_output=True,  # Set this to False to see IDPCG CLI output
                    shell=True,
                    )
                cidr_lst = glob(f"{path_cidrs}/*.pdb")
                execute = partial(
                    idr_aligner,
                    fld_struc=af2_template,
                    case=disorder_cases[2],
                    rs=rs,
                    output=path_cidrs_passed
                    )
                execute_pool = pool_function(execute, cidr_lst, ncores=ncores)
                print(f"Aligning C-IDRs for {id}...")
                for _ in execute_pool:
                    pass
                rs += ncores
                cidrs_passed = glob(f"{path_cidrs_passed}/*.pdb")
                num_cidrs_passed = len(cidrs_passed)

            idr_combos = combo_clash_checker(nidrs_passed, cidrs_passed)
            for i in range(1, nconfs + 1):
                idr_stitcher(
                    idr_arr=idr_combos[i - 1],
                    case=case,
                    fld_arr=af2_template.data_array,
                    output=path_final_ens,
                    idx=i,
                    )

    
    print("Adding hydrogens...")
    idpcg_files = glob(f"{path_final_ens}/*.pdb")
    fix_atoms_pool = pool_function(add_hydrogens, idpcg_files, ncores=ncores)
    for _ in fix_atoms_pool:
        pass
    
    print("Resolving side-chain clashes...")
    # Do not use this with pool_function!
    hydrogenated_files = glob(f"{path_final_ens}/*.pdb")
    cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
    for _ in cc_pool:
        pass
        
    # Make 100 PDBs as an ensemble file to save space
    run_pdbtools = subprocess.run(
            [f"pdb_mkensemble {path_final_ens}/*.pdb > {path_final_ens}/{id}_idpcg_n{nconfs}.pdb"],
            capture_output=True,  # Set this to False to see IDPCG CLI output
            shell=True,
            )
    
    # Cleanup temporary files
    os.system(f"rm -rf {path_final_ens}/temp*")
    os.system(f"rm -rf {path_final_ens}/conformer*")
    os.system(f"rm -rf {path_final_ens}/energies.log")
    print(f"Finished: {id}.")
