from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Dict, List, Tuple, Iterable, Union

import matplotlib.pyplot as plt
import numpy as np


def load_json(path: str) -> Dict:
    with open(path, 'r', encoding='utf-8') as fh:
        return json.load(fh)


def find_ss_entries_for_uid(ss_db: Dict[str, dict], uid: str) -> List[Tuple[str, dict]]:
    """Return list of (key, entry) from ss_db that correspond to uid.
    Matching heuristics: key startswith(uid) or key.split('_')[0] == uid or uid in key.
    """
    matches = []
    for k, v in ss_db.items():
        splitted_k = k.split('_')
        if k.startswith(uid) or splitted_k[0]+splitted_k[1] == uid or uid in k:
            matches.append((k, v))
    return matches


def parse_resids(resids_field: str, dssp_len: int) -> List[int]:
    """Parse resids field which is typically a comma-separated list of ints.
    If parsing fails, fall back to 1..dssp_len.
    """
    try:
        parts = [p.strip() for p in resids_field.split(',') if p.strip()]
        res = [int(x) for x in parts]
        if len(res) != dssp_len:
            # fallback
            return list(range(1, dssp_len + 1))
        return res
    except Exception:
        return list(range(1, dssp_len + 1))


def count_ss_in_ranges(dssp: str, resids: List[int], ranges: List[List[int]]) -> Dict[str, int]:
    """Count occurrences of 'L','H','E' inside the provided 1-based ranges.
    dssp: string where each character corresponds to a residue in resids order.
    resids: list of 1-based residue numbers aligned to dssp positions.
    ranges: list of [start,end] inclusive ranges (1-based)
    Returns dict with counts for keys 'L','H','E' and 'total'
    """
    counts = {'L': 0, 'H': 0, 'E': 0, 'total': 0}
    # build mapping from resid -> index
    resid_to_idx = {r: i for i, r in enumerate(resids)}
    for start, end in ranges:
        for r in range(start, end + 1):
            idx = resid_to_idx.get(r)
            if idx is None or idx < 0 or idx >= len(dssp):
                continue
            ss = dssp[idx]
            if ss == 'L':
                counts['L'] += 1
            elif ss == 'H':
                counts['H'] += 1
            elif ss == 'E':
                counts['E'] += 1
            counts['total'] += 1
    return counts


def aggregate_over_ids(ss_db: Dict[str, dict], idr_db: Dict[str, List[List[int]]], ids_to_use: List[str] | None = None,
                       min_lengths: List[int] | None = None):
    """Aggregate counts across multiple minimum-IDR-length thresholds.

    Returns (totals_by_thresh, per_id_by_thresh)
    - totals_by_thresh: dict[min_len] -> counts dict
    - per_id_by_thresh: dict[uid] -> dict[min_len] -> counts dict
    """
    if min_lengths is None:
        min_lengths = [1, 50, 100, 250, 500, 1000]
    totals_by_thresh: Dict[int, Dict[str, int]] = {m: {'L': 0, 'H': 0, 'E': 0, 'total': 0} for m in min_lengths}
    per_id: Dict[str, Dict[int, Dict[str, int]]] = {}
    ids = ids_to_use if ids_to_use is not None else list(idr_db.keys())
    for uid in ids:
        ranges = idr_db.get(uid, [])
        ss_entries = find_ss_entries_for_uid(ss_db, uid)
        # initialize per-id structure
        per_id[uid] = {m: {'L': 0, 'H': 0, 'E': 0, 'total': 0, 'matched_ss': len(ss_entries)} for m in min_lengths}
        if not ranges or not ss_entries:
            # leave zeros
            continue
        # determine lengths of each IDR range
        for start, end in ranges:
            length = end - start + 1
            # for each threshold that this range qualifies for, count SS
            qualifying_thresh = [m for m in min_lengths if length >= m]
            if not qualifying_thresh:
                continue
            # process each matching SS entry and add counts for qualifying thresholds
            for key, entry in ss_entries:
                dssp = entry.get('dssp', '')
                if not dssp:
                    continue
                resids_field = entry.get('resids', '')
                resids = parse_resids(resids_field, len(dssp))
                counts = count_ss_in_ranges(dssp, resids, [[start, end]])
                for m in qualifying_thresh:
                    per_id[uid][m]['L'] += counts['L']
                    per_id[uid][m]['H'] += counts['H']
                    per_id[uid][m]['E'] += counts['E']
                    per_id[uid][m]['total'] += counts['total']
                    totals_by_thresh[m]['L'] += counts['L']
                    totals_by_thresh[m]['H'] += counts['H']
                    totals_by_thresh[m]['E'] += counts['E']
                    totals_by_thresh[m]['total'] += counts['total']

    return totals_by_thresh, per_id


def plot_bar_counts(
    counts: Dict[Union[int, str], Dict[str, int]],
    out_png: str,
    out_csv: str | None = None,
    *,
    title: str | None = None,
    xlabel: str | None = None,
    label_header: str = 'min_length',
    custom_labels: Iterable[str] | None = None,
):
    """Plot grouped bar chart of L/H/E percentages.

    counts: mapping group -> {L,H,E,total}
    group can be an int (e.g., min IDR length) or a string label (e.g., 'all').
    If custom_labels provided, they override the x tick labels order (must align with counts order).
    """
    # Build CSV summary and grouped bar plot across groups
    # Ensure stable sort for heterogeneous keys
    def _sort_key(k: Union[int, str]):
        return (0, k) if isinstance(k, int) else (1, str(k))
    thresholds = sorted(counts.keys(), key=_sort_key)
    # prepare arrays
    Ls = [counts[t].get('L', 0) for t in thresholds]
    Hs = [counts[t].get('H', 0) for t in thresholds]
    Es = [counts[t].get('E', 0) for t in thresholds]
    tots = [counts[t].get('total', 0) for t in thresholds]

    # compute percents, handle zero totals
    Lp = [100.0 * Ls[i] / tots[i] if tots[i] > 0 else 0.0 for i in range(len(thresholds))]
    Hp = [100.0 * Hs[i] / tots[i] if tots[i] > 0 else 0.0 for i in range(len(thresholds))]
    Ep = [100.0 * Es[i] / tots[i] if tots[i] > 0 else 0.0 for i in range(len(thresholds))]

    labels = list(custom_labels) if custom_labels is not None else [str(t) for t in thresholds]
    x = np.arange(len(thresholds))
    width = 0.25

    fig, ax = plt.subplots(figsize=(max(6, len(thresholds) * 1.5), 4), dpi=300)
    rects1 = ax.bar(x - width, Lp, width, label='L (loop)', color='#4C72B0', edgecolor='black')
    rects2 = ax.bar(x, Hp, width, label='H (α-helix)', color='#55A868', edgecolor='black')
    rects3 = ax.bar(x + width, Ep, width, label='E (extended β)', color='#C44E52', edgecolor='black')

    ax.set_ylabel('Percent of residues (%)')
    ax.set_ylim(0, 100)
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=12)
    ax.set_xlabel(xlabel if xlabel is not None else 'Minimum IDR length (aa)')
    ax.set_title(title if title is not None else 'Secondary-structure composition vs minimum IDR length')
    ax.legend()

    # annotate bars with percent
    def _autolabel(rects, vals):
        for rect, v in zip(rects, vals):
            h = rect.get_height()
            ax.text(rect.get_x() + rect.get_width() / 2.0, h + 1.0, f"{v:.1f}%", ha='center', va='bottom', fontsize=9)

    _autolabel(rects1, Lp)
    _autolabel(rects2, Hp)
    _autolabel(rects3, Ep)

    plt.tight_layout()
    fig.savefig(out_png)
    plt.close(fig)

    # write CSV summary
    if out_csv:
        import csv
        with open(out_csv, 'w', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh)
            header = [label_header, 'count_L', 'count_H', 'count_E', 'total', 'pct_L', 'pct_H', 'pct_E']
            w.writerow(header)
            for i, t in enumerate(thresholds):
                w.writerow([t, Ls[i], Hs[i], Es[i], tots[i], f"{Lp[i]:.6f}", f"{Hp[i]:.6f}", f"{Ep[i]:.6f}"])


def iter_json_files(root: Union[str, Path]) -> Iterable[Path]:
    """Yield all .json files under root recursively."""
    root = Path(root)
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            if fn.lower().endswith('.json'):
                yield Path(dirpath) / fn


def aggregate_from_json_dir_with_thresholds(json_dir: Union[str, Path], min_lengths: List[int]) -> Tuple[Dict[int, Dict[str, int]], Dict[str, int]]:
    """Aggregate L/H/E counts across DSSP entries grouped by minimum sequence length thresholds.

    Each DSSP entry is treated as one IDR whose length is len(dssp).
    For every threshold m satisfied by length >= m, we add the FULL sequence counts
    (L/H/E residues counted separately; total counts every residue regardless of state).

    Returns (counts_by_thresh, diagnostics)
    diagnostics keys: files_parsed, entries_seen, residues_total, residues_LHE
    """
    counts_by_thresh: Dict[int, Dict[str, int]] = {m: {'L': 0, 'H': 0, 'E': 0, 'total': 0} for m in min_lengths}
    files_parsed = 0
    entries_seen = 0
    residues_total = 0
    residues_LHE = 0
    for jf in iter_json_files(json_dir):
        try:
            db = load_json(str(jf))
        except Exception:
            continue
        files_parsed += 1
        if not isinstance(db, dict):
            continue
        for _k, entry in db.items():
            if not isinstance(entry, dict):
                continue
            dssp = entry.get('dssp', '')
            if not dssp:
                continue
            entries_seen += 1
            length = len(dssp)
            residues_total += length
            qualifying = [m for m in min_lengths if length >= m]
            if not qualifying:
                continue
            # pre-count this entry once
            Lc = Hc = Ec = 0
            for ch in dssp:
                if ch == 'L':
                    Lc += 1
                elif ch == 'H':
                    Hc += 1
                elif ch == 'E':
                    Ec += 1
            residues_LHE += (Lc + Hc + Ec)
            for m in qualifying:
                counts_by_thresh[m]['L'] += Lc
                counts_by_thresh[m]['H'] += Hc
                counts_by_thresh[m]['E'] += Ec
                counts_by_thresh[m]['total'] += length  # denominator counts all residues like legacy mode
    diagnostics = {
        'files_parsed': files_parsed,
        'entries_seen': entries_seen,
        'residues_total': residues_total,
        'residues_LHE': residues_LHE,
    }
    return counts_by_thresh, diagnostics


def write_per_id_csv(per_id: Dict[str, Dict[int, Dict[str, int]]], thresholds: List[int], path: str):
    """Write a per-ID diagnostics CSV.

    per_id: mapping uid -> mapping threshold -> counts dict
    thresholds: list of thresholds (ints) in the order to write columns
    """
    import csv
    # build header: uniprot, matched_ss_entries, then for each threshold columns
    header = ['uniprot', 'matched_ss_entries']
    for m in thresholds:
        header.extend([f'count_L_{m}', f'count_H_{m}', f'count_E_{m}', f'total_{m}'])
    with open(path, 'w', newline='', encoding='utf-8') as fh:
        w = csv.writer(fh)
        w.writerow(header)
        for uid, info in sorted(per_id.items()):
            row = [uid]
            # matched_ss was stored as matched_ss in per_id initialiser
            # but may be nested per threshold; try to retrieve a reasonable value
            # prefer a top-level matched_ss if present, otherwise sum of matched flags
            matched = 0
            # the previous code stored matched_ss as per_id[uid][m]['matched_ss'] for each m
            # try to get any of them
            for m in thresholds:
                entry = info.get(m)
                if entry is not None and entry.get('matched_ss'):
                    matched = entry.get('matched_ss')
                    break
            row.append(matched)
            for m in thresholds:
                entry = info.get(m, {})
                row.extend([entry.get('L', 0), entry.get('H', 0), entry.get('E', 0), entry.get('total', 0)])
            w.writerow(row)


def parse_args(argv=None):
    ap = argparse.ArgumentParser(description='Plot aggregated percent L/H/E from DSSP data.')
    mode = ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--json-dir', help='Directory to scan recursively for *.json with DSSP entries; ignores IDR ranges')
    mode.add_argument('--ss-json', help='Path to secondary-structure JSON (legacy IDR mode)')
    ap.add_argument('--idr-json', help='Path to IDR boundaries JSON (legacy IDR mode)')
    ap.add_argument('--ids', help='Optional file with one UniProt ID per line to restrict analysis (legacy IDR mode)')
    ap.add_argument('--min-lengths', help='Comma-separated list of minimum lengths (folder mode & legacy). Default: 1,50,100,500,1000')
    ap.add_argument('-o', '--out', required=True, help='Output PNG path (and CSV alongside)')
    return ap.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)

    out_png = args.out
    out_csv = None
    per_id_csv = None
    try:
        p = Path(out_png)
        out_dir = p.parent
        out_dir.mkdir(parents=True, exist_ok=True)
        out_csv = str(p.with_suffix('.csv'))
    except Exception:
        out_csv = None

    # Parse min lengths (applies to both modes)
    if args.min_lengths:
        try:
            min_lengths = [int(x) for x in args.min_lengths.split(',') if x.strip()]
        except ValueError:
            raise SystemExit('Could not parse --min-lengths; must be comma-separated ints')
    else:
        min_lengths = [1, 50, 100, 500, 1000]

    # Folder mode: scan json-dir and aggregate across all DSSP entries with thresholds
    if args.json_dir:
        counts_by_thresh, diag = aggregate_from_json_dir_with_thresholds(args.json_dir, min_lengths)
        overall_total = sum(v.get('total', 0) for v in counts_by_thresh.values())
        print(
            f"Scanned directory '{args.json_dir}': {diag.get('files_parsed', 0)} files, "
            f"{diag.get('entries_seen', 0)} DSSP entries, total residues {diag.get('residues_total', 0)}; L/H/E residues {diag.get('residues_LHE', 0)}."
        )
        if overall_total == 0:
            print('No L/H/E residues found in DSSP entries under the provided directory.')
            raise SystemExit(1)
        plot_bar_counts(
            counts_by_thresh,
            out_png,
            out_csv,
            title='Secondary-structure composition vs minimum sequence length',
            xlabel='Minimum sequence length (aa)',
            label_header='min_length'
        )
        print(f'Wrote plot to {out_png} and summary CSV to {out_csv}')
        return 0

    # Legacy IDR mode
    if not args.ss_json or not args.idr_json:
        raise SystemExit('Legacy mode requires --ss-json and --idr-json')
    ss_db = load_json(args.ss_json)
    idr_db = load_json(args.idr_json)
    ids = None
    if args.ids:
        with open(args.ids, 'r', encoding='utf-8') as fh:
            ids = [line.strip() for line in fh if line.strip()]

    counts, per_id = aggregate_over_ids(ss_db, idr_db, ids_to_use=ids, min_lengths=min_lengths)

    # counts is a dict[min_len] -> counts dict. compute overall total across thresholds
    def _sort_key(k: Union[int, str]):
        return (0, k) if isinstance(k, int) else (1, str(k))
    thresholds = sorted(counts.keys(), key=_sort_key)
    overall_total = sum(counts[t].get('total', 0) for t in thresholds)

    # diagnostics: how many IDs had any matched SS entries and non-zero counts
    n_ids = len(per_id)
    n_with_matches = sum(1 for uid, info in per_id.items() if any(info.get(m, {}).get('matched_ss', 0) for m in thresholds))
    print(f'Processed {n_ids} IDs; {n_with_matches} had matching SS entries. Total residues counted across all thresholds: {overall_total}')

    if overall_total == 0:
        print('No residues counted in provided IDR ranges across all IDs.')
        if per_id_csv:
            try:
                write_per_id_csv(per_id, [t for t in thresholds if isinstance(t, int)], per_id_csv)
                print(f'Wrote per-ID diagnostics to {per_id_csv}')
            except Exception as e:
                print(f'Could not write per-ID diagnostics to {per_id_csv}: {e}')
        raise SystemExit(1)

    plot_bar_counts(counts, out_png, out_csv)
    if per_id_csv:
        try:
            write_per_id_csv(per_id, [t for t in thresholds if isinstance(t, int)], per_id_csv)
        except Exception as e:
            print(f'Could not write per-ID CSV to {per_id_csv}: {e}')
    print(f'Wrote plot to {out_png} and summary CSV to {out_csv}; per-ID CSV at {per_id_csv}')


if __name__ == '__main__':
    raise SystemExit(main())
