"""
Compute local backbone curvature (κ) along the Cα trace for single-model PDB files,
annotate residues that fall within IDR ranges from a JSON file, and export per-residue
and per-IDR summaries.

Curvature definition (discrete):
  κ_i = 2*sin(θ_i/2) / |r_{i+1} - r_{i-1}|
where θ_i is the angle between vectors (r_i - r_{i-1}) and (r_{i+1} - r_i).

Key features:
- Handles chain breaks (missing residues / big CA-CA jumps)
- Flexible IDR coordinate space: 'index' (1..N by CA order) or 'pdb' (resseq/icode)
- Exports per-residue and per-IDR CSVs
- Units selectable: Å^-1 (default) or nm^-1

Assumptions:
- PDB filename stem equals UniProt ID (e.g., Q5VUM1.pdb -> "Q5VUM1").
- Single model PDBs; if multiple models exist, the first model is used.

Usage:
  python compute_curvature.py \
      --pdb-dir ./pdbs \
      --idr-json ./idrs.json \
      --chain-id A \
      --idr-coords index \
      --units A-1 \
      --outdir ./curvature_out
"""
import os
import json
import argparse
from glob import glob
from typing import Dict, List, Tuple, Optional

import numpy as np
import pandas as pd
from Bio.PDB import PDBParser

# ------------------------------ Helpers ------------------------------

def stem_as_uniprot_id(pdb_path: str) -> str:
    return os.path.splitext(os.path.basename(pdb_path))[0]

def load_idr_db(json_path: str) -> Dict[str, List[List[int]]]:
    with open(json_path, "r") as fh:
        db = json.load(fh)
    # Normalize: ensure each value is a list of [start, end] pairs (1-based inclusive)
    norm = {}
    for k, v in db.items():
        segs = []
        for seg in v:
            if isinstance(seg, (list, tuple)) and len(seg) == 2:
                a, b = int(seg[0]), int(seg[1])
                if a > b:
                    a, b = b, a
                segs.append([a, b])
        norm[k] = segs
    return norm

def safe_acos(x: float) -> float:
    return np.arccos(np.clip(x, -1.0, 1.0))

def detect_chain_breaks(coords: np.ndarray,
                        resseq: List[int],
                        icode: List[str],
                        ca_ca_max: float = 4.5) -> np.ndarray:
    """
    Return a boolean mask 'is_break' of length N marking positions i where a break exists
    BETWEEN i and i+1. Criteria:
      - CA-CA distance > ca_ca_max Å
      - or PDB numbering not consecutive (resseq jumps by >1 ignoring icode)
    """
    N = len(coords)
    is_break = np.zeros(N-1, dtype=bool)
    for i in range(N-1):
        d = np.linalg.norm(coords[i+1] - coords[i])
        if d > ca_ca_max:
            is_break[i] = True
            continue
        # numbering check: tolerate insertion codes; require resseq[i+1] == resseq[i] + 1
        if (resseq[i+1] - resseq[i]) != 1:
            is_break[i] = True
    return is_break

def compute_curvature_from_ca(coords: np.ndarray,
                              break_mask: np.ndarray) -> np.ndarray:
    """
    Compute curvature κ_i at internal residues i=1..N-2.
    For termini and around breaks, returns NaN.
    """
    N = len(coords)
    kappa = np.full(N, np.nan, dtype=float)
    if N < 3:
        return kappa

    # Can't compute across breaks: if a break at i-1 or i → kappa[i] invalid
    for i in range(1, N-1):
        if break_mask[i-1] or break_mask[i]:
            continue
        v1 = coords[i]   - coords[i-1]
        v2 = coords[i+1] - coords[i]
        n1 = np.linalg.norm(v1)
        n2 = np.linalg.norm(v2)
        if n1 == 0.0 or n2 == 0.0:
            continue
        cos_th = float(np.dot(v1, v2) / (n1 * n2))
        theta = safe_acos(cos_th)
        chord = np.linalg.norm(coords[i+1] - coords[i-1])
        if chord == 0.0:
            continue
        kappa[i] = 2.0 * np.sin(theta / 2.0) / chord

    return kappa

def nm_scale_factor(units: str) -> float:
    """
    Convert Å^-1 to requested units. κ computed in Å^-1 by default.
    If units == 'nm-1', multiply by 10.0 (since 1 Å = 0.1 nm → Å^-1 = 10 * nm^-1).
    If units == 'A-1', factor = 1.0.
    """
    u = units.strip().lower()
    if u in ("a-1", "å^-1", "ang^-1", "angstrom^-1"):
        return 1.0
    elif u in ("nm-1", "nanometer^-1"):
        return 10.0
    else:
        raise ValueError(f"Unsupported units: {units}. Use 'A-1' or 'nm-1'.")

def build_idr_mask(
    n_res: int,
    resseq: List[int],
    icode: List[str],
    idr_ranges: List[List[int]],
    mode: str
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Build boolean mask (length N residues) of whether each residue is inside any IDR range.
    Also returns an array 'idr_index' that labels which IDR range each residue belongs to
    (0 = not in IDR, 1..K = IDR ordinal).
    mode: 'index' → IDR ranges use sequence index 1..N by CA order (ignores PDB resseq)
          'pdb'   → IDR ranges use PDB residue numbering (resseq, ignoring icode)
    """
    in_idr = np.zeros(n_res, dtype=bool)
    idr_idx = np.zeros(n_res, dtype=int)
    if not idr_ranges:
        return in_idr, idr_idx

    if mode == "index":
        for j, (a, b) in enumerate(idr_ranges, start=1):
            a0 = max(a - 1, 0)
            b0 = min(b - 1, n_res - 1)
            if a0 <= b0:
                in_idr[a0:b0+1] = True
                idr_idx[a0:b0+1] = j
    elif mode == "pdb":
        # Map each position to its resseq, ignore icode
        resseq_arr = np.array(resseq, dtype=int)
        for j, (a, b) in enumerate(idr_ranges, start=1):
            low, high = min(a, b), max(a, b)
            hit = (resseq_arr >= low) & (resseq_arr <= high)
            in_idr[hit] = True
            idr_idx[hit] = np.where(hit, j, idr_idx)
    else:
        raise ValueError("mode must be 'index' or 'pdb'.")

    return in_idr, idr_idx

def residue_table_from_chain(chain) -> pd.DataFrame:
    """
    Extract residue-level table for a Biopython Chain object:
      seq_index: 1..N by CA order
      resseq, icode
      CA coordinates (x,y,z)
    Excludes residues lacking a CA atom.
    """
    rows = []
    for res in chain.get_residues():
        het, resseq, icode = res.get_id()  # (' ', 42, ' ') for standard residues
        # skip HETATM and waters
        if het.strip() not in ("", "W"):
            continue
        if "CA" not in res:
            continue
        ca = res["CA"].get_coord()
        rows.append({
            "resseq": int(resseq),
            "icode": icode.strip() or "",
            "x": float(ca[0]),
            "y": float(ca[1]),
            "z": float(ca[2]),
        })
    if not rows:
        return pd.DataFrame(columns=["seq_index","resseq","icode","x","y","z"])
    df = pd.DataFrame(rows)
    df = df.sort_values(["resseq","icode"], kind="mergesort").reset_index(drop=True)
    df.insert(0, "seq_index", np.arange(1, len(df)+1))
    return df

# ------------------------------ Main compute ------------------------------

def process_pdb(
    pdb_path: str,
    chain_id: Optional[str],
    idr_db: Dict[str, List[List[int]]],
    idr_coords_mode: str,
    kappa_units: str
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns:
      per_residue_df, per_idr_df
    (Empty dataframes if nothing is computed.)
    """
    uniprot_id = stem_as_uniprot_id(pdb_path)
    idr_ranges = idr_db.get(uniprot_id, [])

    parser = PDBParser(QUIET=True)
    structure = parser.get_structure(uniprot_id, pdb_path)
    model = structure[0]

    chains = [c for c in model.get_chains()] if (chain_id is None or chain_id.lower()=="all") else [model[chain_id]]

    per_residue_records = []
    per_idr_records = []

    sf = nm_scale_factor(kappa_units)

    for ch in chains:
        df = residue_table_from_chain(ch)
        if df.empty:
            continue

        coords = df[["x","y","z"]].to_numpy(float)
        resseq = df["resseq"].tolist()
        icode  = df["icode"].tolist()

        # Detect breaks
        br = detect_chain_breaks(coords, resseq, icode, ca_ca_max=4.5)

        # Curvature
        kappa = compute_curvature_from_ca(coords, br) * sf  # convert units

        # IDR mask
        in_idr, idr_idx = build_idr_mask(
            n_res=len(df),
            resseq=resseq,
            icode=icode,
            idr_ranges=idr_ranges,
            mode=idr_coords_mode
        )

        tmp = df.copy()
        tmp.insert(0, "uniprot_id", uniprot_id)
        tmp.insert(1, "pdb_file", os.path.basename(pdb_path))
        tmp.insert(2, "chain", ch.id)
        tmp["kappa"] = kappa
        tmp["kappa_units"] = kappa_units
        tmp["in_idr"] = in_idr
        tmp["idr_index"] = idr_idx

        per_residue_records.append(tmp)

        # Summaries per IDR
        if idr_ranges:
            for j, (a, b) in enumerate(idr_ranges, start=1):
                mask = (tmp["idr_index"].values == j) & np.isfinite(tmp["kappa"].values)
                n_valid = int(mask.sum())
                seg_len_res = int((b - a + 1)) if a <= b else int((a - b + 1))
                if n_valid > 0:
                    kseg = tmp.loc[mask, "kappa"].to_numpy(float)
                    # crude arc-length using CA-CA chord sums inside masked region
                    idxs = tmp.index[mask].to_numpy()
                    seg_coords = tmp.loc[idxs, ["x","y","z"]].to_numpy(float)
                    if len(seg_coords) >= 2:
                        diffs = np.linalg.norm(np.diff(seg_coords, axis=0), axis=1)
                        arc = float(np.sum(diffs))
                    else:
                        arc = 0.0

                    per_idr_records.append({
                        "uniprot_id": uniprot_id,
                        "pdb_file": os.path.basename(pdb_path),
                        "chain": ch.id,
                        "idr_index": j,
                        "idr_start": a,
                        "idr_end": b,
                        "segment_length_res": seg_len_res,
                        "n_valid": n_valid,
                        "frac_valid": n_valid / max(seg_len_res, 1),
                        "kappa_units": kappa_units,
                        "kappa_mean": float(np.mean(kseg)),
                        "kappa_median": float(np.median(kseg)),
                        "kappa_std": float(np.std(kseg, ddof=1)) if n_valid > 1 else np.nan,
                        "arc_length_A": arc,  # arc-length in Å
                        "arc_length_nm": arc / 10.0
                    })
                else:
                    per_idr_records.append({
                        "uniprot_id": uniprot_id,
                        "pdb_file": os.path.basename(pdb_path),
                        "chain": ch.id,
                        "idr_index": j,
                        "idr_start": a,
                        "idr_end": b,
                        "segment_length_res": seg_len_res,
                        "n_valid": 0,
                        "frac_valid": 0.0,
                        "kappa_units": kappa_units,
                        "kappa_mean": np.nan,
                        "kappa_median": np.nan,
                        "kappa_std": np.nan,
                        "arc_length_A": np.nan,
                        "arc_length_nm": np.nan
                    })

    per_residue_df = pd.concat(per_residue_records, ignore_index=True) if per_residue_records else pd.DataFrame()
    # per_idr_records is a list of dicts → build a DataFrame directly
    per_idr_df = pd.DataFrame(per_idr_records) if per_idr_records else pd.DataFrame()
    return per_residue_df, per_idr_df

# ------------------------------ CLI ------------------------------

def main():
    ap = argparse.ArgumentParser(description="Compute local chain curvature (κ) from PDB Cα traces with IDR annotation.")
    ap.add_argument("--pdb-dir", required=True, help="Directory containing single-model PDB files.")
    ap.add_argument("--idr-json", required=True, help="JSON file with IDR ranges per UniProt ID.")
    ap.add_argument("--glob", default="*.pdb", help="Glob for PDBs (default: *.pdb).")
    ap.add_argument("--chain-id", default="A",
                    help="Chain ID to process (e.g., 'A'). Use 'all' to process all chains in each PDB. Default: A")
    ap.add_argument("--idr-coords", choices=["index","pdb"], default="index",
                    help="Interpret IDR ranges in 'index' (1..N by CA order) or 'pdb' (resseq). Default: index")
    ap.add_argument("--units", choices=["A-1","nm-1"], default="A-1",
                    help="Units for curvature κ. Default: A-1")
    ap.add_argument("--outdir", default="./curvature_out", help="Output directory. Default: ./curvature_out")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)

    idr_db = load_idr_db(args.idr_json)

    all_per_res = []
    all_per_idr = []

    pdb_paths = sorted(glob(os.path.join(args.pdb_dir, args.glob)))
    if not pdb_paths:
        print(f"[WARN] No PDB files matched {os.path.join(args.pdb_dir, args.glob)}")
    for p in pdb_paths:
        try:
            per_res, per_idr = process_pdb(
                pdb_path=p,
                chain_id=args.chain_id,
                idr_db=idr_db,
                idr_coords_mode=args.idr_coords,
                kappa_units=args.units
            )
            if not per_res.empty:
                all_per_res.append(per_res)
            if not per_idr.empty:
                all_per_idr.append(per_idr)
        except KeyError as e:
            # chain missing etc.
            print(f"[WARN] Skipping {os.path.basename(p)} due to error: {e}")
        except Exception as e:
            print(f"[WARN] Error on {os.path.basename(p)}: {e}")

    if all_per_res:
        per_res_df = pd.concat(all_per_res, ignore_index=True)
        out_res = os.path.join(args.outdir, "per_residue_curvature.csv")
        per_res_df.to_csv(out_res, index=False)
        print(f"[OK] Wrote per-residue: {out_res}")
    else:
        print("[INFO] No per-residue data produced.")

    if all_per_idr:
        per_idr_df = pd.concat(all_per_idr, ignore_index=True)
        out_idr = os.path.join(args.outdir, "per_idr_summary.csv")
        per_idr_df.to_csv(out_idr, index=False)
        print(f"[OK] Wrote per-IDR summary: {out_idr}")
    else:
        print("[INFO] No per-IDR summary produced (no IDR matches or no data).")

if __name__ == "__main__":
    main()
