'''
Main builder function for easy fast cases (N-IDR, C-IDR, and single IDP).

Number of IDR residues do not exceed 150 AA.

REQUIREMENTS
------------
* IDPConformerGenerator v0.7.25
* OpenMM v8.2.0
* pdb-tools v2.5.0
* PDBFixer v1.9.0
* Master database, IDs to process, folder of AF2-PDBs as templates

Date: January 21, 2025 (v3.3)
Author: Zi Hao Liu
'''
import re
import sys
import json
import os
import subprocess

import numpy as np

from pdbfixer import PDBFixer
from glob import glob

from openmm.app import (
    PDBFile,
    ForceField,
    Simulation,
    HBonds,
    NoCutoff,
    )
from openmm import LangevinIntegrator, CustomExternalForce
from openmm.unit import *

from idpconfgen import Path
from idpconfgen.libs.libstructure import (
    Structure,
    col_resSeq,
    structure_to_pdb,
    write_PDB,
    )
from idpconfgen.libs.libmulticore import pool_function


# Change job parameters here.
# Set number will depend on the name of the script
set_num = int(re.search(r'\d+', sys.argv[0]).group())  
nconfs = 100
ncores = 16
cc_ncores = 10  # Will use up a lot of resources, keep this small
output_directory = f"../AFX_Category1/Category1_ens{set_num}"
easy_ids_file = f"../databases/Category1_IDs/ID{set_num}.txt"
idpcg_database = "../databases/idpconfgen_database.json"
master_db_file = "../databases/AlphaFlex_database_Jul2024.json"
max_residues_file = "../databases/AF2_9606_HUMAN_v4_num_residues.json"
af2_pdbs = glob("../databases/AF2_9606_PDB/*.pdb")


def resolve_clash(pdb_file):
    """
    Inspired by Oliver Sun.
    
    Resolve clashes in the protein file through short md simulation steps while keeping
    protein backbone fixed during the process.
    """
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    pdb = PDBFile(pdb_file)
    forcefield = ForceField('amber99sb.xml')

    # Set up the OpenMM system
    system = forcefield.createSystem(
        pdb.topology, constraints=HBonds, nonbondedMethod=NoCutoff
    )

    # Select side-chain atoms by excluding backbone atoms
    sidechain_atoms = []
    for atom in pdb.topology.atoms():
            sidechain_atoms.append(atom.index)

    # Apply harmonic constraints to backbone atoms
    k = 10.0 * kilocalories_per_mole / angstrom**2  # Adjust this if needed
    constraint_force = CustomExternalForce('0.5 * k * ((x - x0)^2 + (y - y0)^2 + (z - z0)^2)')
    constraint_force.addPerParticleParameter('x0')
    constraint_force.addPerParticleParameter('y0')
    constraint_force.addPerParticleParameter('z0')
    constraint_force.addGlobalParameter('k', k)

    for atom in pdb.topology.atoms():
        if atom.index not in sidechain_atoms:  # Apply only to backbone atoms
            position = pdb.positions[atom.index]
            constraint_force.addParticle(atom.index, [position.x, position.y, position.z])

    system.addForce(constraint_force)

    # Set up the simulation
    integrator = LangevinIntegrator(300*kelvin, 1/picosecond, 0.002*picoseconds) # type: ignore
    simulation = Simulation(pdb.topology, system, integrator)
    simulation.context.setPositions(pdb.positions)

    # Minimize energy (with constraints active)
    simulation.minimizeEnergy(maxIterations=1000)

    # Save the minimized structure
    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(f"{folder}/{name}_cr.pdb", 'w') as f:
        PDBFile.writeFile(simulation.topology, positions, f)
    
    os.remove(pdb_file)


def add_hydrogens(pdb_file, pH=7.4):
    name = os.path.splitext(os.path.basename(pdb_file))[0]
    folder = os.path.dirname(os.path.abspath(pdb_file))
    
    fixer = PDBFixer(filename=pdb_file)
    fixer.findMissingResidues()
    fixer.findMissingAtoms()
    fixer.addMissingHydrogens(pH=pH)
    
    PDBFile.writeFile(
        fixer.topology,
        fixer.positions,
        open(f'{folder}/{name}_pro.pdb', 'w')
        )
    
    os.remove(pdb_file)


# Processing below
try:
    with open(master_db_file, 'r') as f:
        master_db = json.load(f)
    with open(easy_ids_file, 'r') as f:
        easy_ids = [line.strip() for line in f]
    with open(max_residues_file, 'r') as f:
        max_residues = json.load(f)
except FileNotFoundError:
    print("Error: file not found for database, IDs, or max residues. Please check paths.")
    exit()

# Checks for output directory
if not os.path.exists(output_directory):
    os.mkdir(output_directory)

'''
Main builder scripts below. There are 2 cases for easy:

1. Just an IDP
- "IDR" spans 1-num_res

2. N-IDR or C-IDR or both
- "IDR" contains [1,X] and [Y,num_res] and that's it
- Find and cut out the folded domain and store it as a template
- IDRs must have 2 residue overhangs with folded domain
'''
for id in easy_ids:
    # Set-up temporary directories
    path_final_ens = f"{output_directory}/{id}"
    if not os.path.exists(path_final_ens):
        os.mkdir(path_final_ens)
    path_templates = f"{path_final_ens}/temp_templates"
    os.mkdir(path_templates)

    # Find entries in database
    pdb_path = [p for p in af2_pdbs if id in p][0]
    struc = Structure(Path(pdb_path))
    struc.build()
    sequence = next(iter(struc.fasta.values()))
    details = master_db[id]['idrs']
    num_res = max_residues[id]

    print(f"Building {nconfs} conformers for {id}...")
    # Case #1, single IDP
    if len(details) == 1 and details[0][0] == 1 and details[0][1] == num_res:
        num_res = int(num_res)
        if num_res < 200:
            run_idpcg = subprocess.run(
                [f"idpconfgen build \
                    -seq {sequence} \
                    -db {idpcg_database} \
                    --dloop-off --dany \
                    -nc {nconfs} -n {ncores} \
                    -of {path_final_ens}"
                ],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )
        else:
            run_idpcg = subprocess.run(
                [f"idpconfgen build \
                    -seq {sequence} \
                    -db {idpcg_database} \
                    --dloop-off --dany --long \
                    -nc {nconfs} -n {ncores} \
                    -of {path_final_ens}"
                ],
                capture_output=True,  # Set this to False to see IDPCG CLI output
                shell=True,
                )

    # Case #2, N-IDR and C-IDR
    elif len(details) <= 2:
        struc_arr = struc.data_array
        seqs = struc.data_array[:, col_resSeq].astype(int)
        seq_mask = np.ones(seqs.shape, dtype=bool)

        for start, end, in details:
            seq_mask[(seqs >= start) & (seqs <= end)] = False

        filtered_struc_arr = struc_arr[seq_mask]
        template_struc = structure_to_pdb(filtered_struc_arr)
        output_template_path = path_templates + f"/{id}_processed.pdb"
        write_PDB(template_struc, output_template_path)

        run_idpcg = subprocess.run(
            [f"idpconfgen ldrs \
                -seq {sequence} \
                -db {idpcg_database} \
                --dloop-off --dany \
                -nc {nconfs} -n {ncores} \
                -of {path_final_ens} \
                -fld {output_template_path}"
            ],
            capture_output=True,  # Set this to False to see IDPCG CLI output
            shell=True,
            )
        
    else:
        # Should not reach here, if it does, just skip it
        continue

    print("Adding hydrogens...")
    idpcg_files = glob(f"{path_final_ens}/*.pdb")
    fix_atoms_pool = pool_function(add_hydrogens, idpcg_files, ncores=ncores)
    for _ in fix_atoms_pool:
        pass
    
    print("Resolving side-chain clashes...")
    hydrogenated_files = glob(f"{path_final_ens}/*.pdb")
    cc_pool = pool_function(resolve_clash, hydrogenated_files, ncores=cc_ncores)
    for _ in cc_pool:
        pass

    # Make 100 PDBs as an ensemble file to save space
    run_pdbtools = subprocess.run(
            [f"pdb_mkensemble {path_final_ens}/*.pdb > {path_final_ens}/{id}_idpcg_n{nconfs}.pdb"],
            capture_output=True,  # Set this to False to see IDPCG CLI output
            shell=True,
            )
    # Cleanup temporary files
    os.system(f"rm -rf {path_final_ens}/conformer*")
    os.system(f"rm -rf {path_final_ens}/temp*")
    os.system(f"rm -rf {path_final_ens}/energies.log")
    print(f"Finished: {id}.")
