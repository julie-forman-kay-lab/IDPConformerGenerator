import json
import os
import math
from glob import glob
from statistics import mean, stdev


# Folder containing JSON files with torsion angles
json_folder = "../analysis/torsions/TORSIONS"
output_file = "../analysis/torsions/TORSION_CATEGORIES.txt"

# Convert degree ranges to radians
# Alpha helix: phi in (-180, 10) and psi in (-120, 45)
alpha_phi_min = math.radians(-180.0)
alpha_phi_max = math.radians(10.0)
alpha_psi_min = math.radians(-120.0)
alpha_psi_max = math.radians(45.0)

# Beta sheet: phi in (-180, 0) and psi in ((-180, -120) or (45, 180))
beta_phi_min = math.radians(-180.0)
beta_phi_max = math.radians(0.0)
beta_psi_min1 = math.radians(-180.0)
beta_psi_max1 = math.radians(-120.0)
beta_psi_min2 = math.radians(45.0)
beta_psi_max2 = math.radians(180.0)


def classify_torsion(phi, psi):
    """
    Classify a (phi, psi) pair as alpha, beta, or coil.
    
    Args:
        phi (float): Phi angle in radians
        psi (float): Psi angle in radians
    
    Returns:
        str: 'alpha', 'beta', or 'coil'
    """
    # Alpha helix region
    if (alpha_phi_min < phi < alpha_phi_max) and (alpha_psi_min < psi < alpha_psi_max):
        return 'alpha'
    
    # Beta sheet region
    elif (beta_phi_min < phi < beta_phi_max) and (
        (beta_psi_min1 < psi < beta_psi_max1) or (beta_psi_min2 < psi < beta_psi_max2)
    ):
        return 'beta'
    
    # Everything else is coil
    else:
        return 'coil'


def summarize_percentages(values):
    if not values:
        return 0.0, 0.0
    if len(values) == 1:
        return values[0], 0.0
    return mean(values), stdev(values)


def main():
    # Find all JSON files in the folder
    json_files = glob(f"{json_folder}/*.json")
    
    if not json_files:
        print(f"No JSON files found in {json_folder}")
        return
    
    print(f"Found {len(json_files)} JSON files to analyze")
    
    # Counters for secondary structure
    alpha_count = 0
    beta_count = 0
    coil_count = 0
    total_count = 0
    alpha_per_file = []
    beta_per_file = []
    coil_per_file = []
    
    # Process each JSON file
    for json_file in json_files:
        try:
            with open(json_file, 'r') as f:
                data = json.load(f)
            
            # Iterate through each conformer in the file
            file_alpha = 0
            file_beta = 0
            file_coil = 0
            file_total = 0
            for conformer_id, angles in data.items():
                phi_list = angles.get('phi', [])
                psi_list = angles.get('psi', [])
                
                # Process each (phi, psi) pair
                # Note: phi and psi lists should have the same length
                for phi, psi in zip(phi_list, psi_list):
                    classification = classify_torsion(phi, psi)
                    
                    if classification == 'alpha':
                        alpha_count += 1
                        file_alpha += 1
                    elif classification == 'beta':
                        beta_count += 1
                        file_beta += 1
                    else:
                        coil_count += 1
                        file_coil += 1
                    total_count += 1
                    file_total += 1
        
        except Exception as e:
            print(f"Error processing {json_file}: {e}")
            continue

        if file_total > 0:
            alpha_per_file.append(100.0 * file_alpha / file_total)
            beta_per_file.append(100.0 * file_beta / file_total)
            coil_per_file.append(100.0 * file_coil / file_total)
    
    # Calculate percentages
    if total_count == 0:
        print("No torsion angles found to analyze")
        return
    
    alpha_pct = (alpha_count / total_count) * 100
    beta_pct = (beta_count / total_count) * 100
    coil_pct = (coil_count / total_count) * 100

    alpha_mean, alpha_std = summarize_percentages(alpha_per_file)
    beta_mean, beta_std = summarize_percentages(beta_per_file)
    coil_mean, coil_std = summarize_percentages(coil_per_file)
    samples = len(alpha_per_file)
    
    # Prepare output
    results = [
        "Secondary Structure Analysis Results",
        "=" * 50,
        f"Total torsion angle pairs analyzed: {total_count}",
        "",
        f"Alpha region: {alpha_count} ({alpha_pct:.2f}%) | per-file {alpha_mean:.2f} ± {alpha_std:.2f}% (n={samples})",
        f"Beta region:  {beta_count} ({beta_pct:.2f}%) | per-file {beta_mean:.2f} ± {beta_std:.2f}% (n={samples})",
        f"Coil:        {coil_count} ({coil_pct:.2f}%) | per-file {coil_mean:.2f} ± {coil_std:.2f}% (n={samples})",
        "",
        "Classification criteria (converted to radians):",
        f"  Alpha: phi in ({alpha_phi_min:.4f}, {alpha_phi_max:.4f}) and psi in ({alpha_psi_min:.4f}, {alpha_psi_max:.4f})",
        f"  Beta:  phi in ({beta_phi_min:.4f}, {beta_phi_max:.4f}) and psi in (({beta_psi_min1:.4f}, {beta_psi_max1:.4f}) or ({beta_psi_min2:.4f}, {beta_psi_max2:.4f}))",
        f"  Coil:  All other regions"
    ]
    
    # Print to console
    for line in results:
        print(line)
    
    # Save to file
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    with open(output_file, 'w') as f:
        f.write('\n'.join(results))
    
    print(f"\nResults saved to: {output_file}")


if __name__ == "__main__":
    main()
