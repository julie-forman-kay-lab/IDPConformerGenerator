import json
import matplotlib.pyplot as plt


# Define file paths
data_file_1 = "../analysis/FILE.JSON"
data_file_2 = "../analysis/FILE2.json"
output_fig_name = "../analysis/plots/TITLE"
output_matches = "../analysis/matched_uniprot_ids.txt"

AXIS_LABEL_FONTSIZE = 18
TICK_LABEL_FONTSIZE = 16

# Load the JSON files
with open(data_file_1, "r") as file:
    data_1 = json.load(file)

with open(data_file_2, "r") as file:
    data_2 = json.load(file)

metrics = ["Rg", "Rh", "Ree", "A", "SASA"]
x_axes = ["Length", "Net Charge", "SCD", "Aromatic Kappa", "Shannon-Entropy", "W-F Complexity"]

# Match entries by sequence
matched_data = {}
matched_ids = []
for key1, values1 in data_1.items():
    sequence_1 = values1["Sequence"]
    
    for key2, values2 in data_2.items():
        sequence_2 = values2["Sequence"]

        if sequence_1 == sequence_2:
            matched_ids.append(key1.split("_")[0])
            matched_data[sequence_1] = {
                "Isolated": values1,
                "Extracted": values2
            }

# Generate plots for each X-axis
for x_axis in x_axes:
    fig, axes = plt.subplots(len(metrics), 1, figsize=(6, 18))
    axes = axes.flatten()

    x_values = [float(matched_data[seq]["Isolated"][x_axis]) for seq in matched_data]

    for i, metric in enumerate(metrics):
        ax = axes[i]

        metric_values_1 = [float(matched_data[seq]["Isolated"][metric][0]) for seq in matched_data]
        metric_errors_1 = [float(matched_data[seq]["Isolated"][metric][1]) for seq in matched_data]
        #metric_values_1 = [float(matched_data[seq]["Isolated"][metric]) for seq in matched_data]

        metric_values_2 = [float(matched_data[seq]["Extracted"][metric][0]) for seq in matched_data]
        metric_errors_2 = [float(matched_data[seq]["Extracted"][metric][1]) for seq in matched_data]
        
        #ax.errorbar(
        #    x_values, metric_values_1, fmt="o", capsize=0, alpha=0.25,
        #    label="AlphaFold", markersize=3, color='black', mfc='none',
        #)
        
        ax.errorbar(
            x_values, metric_values_1, yerr=metric_errors_1, fmt="o", capsize=0, alpha=0.25,
            label="Isolated", markersize=3, color='black', mfc='none', ecolor='black', elinewidth=1, zorder=2
        )
        
        ax.errorbar(
            x_values, metric_values_2, yerr=metric_errors_2, fmt="o", capsize=0, alpha=0.25,
            label="Extracted", markersize=3, color='red', mfc='none', ecolor='red', elinewidth=1, zorder=1
        )

        ax.set_title(metric)
        
        if x_axis == "Length":
            x_axis = "Sequence Length"
        elif x_axis == "Net Charge":
            x_axis = "Net Charge at pH = 7.4"
        elif x_axis == "SCD":
            x_axis = "Sequence Charge Decoration"

        ax.set_xlabel(x_axis, fontsize=AXIS_LABEL_FONTSIZE)

        if metric == "Rg":
            ax.set_ylabel(r"$R_g$ (Å)", fontsize=AXIS_LABEL_FONTSIZE)
            #ax.set_ylim(0, 250)
            ax.set_ylim(0, 40)
        elif metric == "Rh":
            ax.set_ylabel(r"$R_h$ (Å)", fontsize=AXIS_LABEL_FONTSIZE)
            #ax.set_ylim(0, 200)
            ax.set_ylim(0, 30)
        elif metric == "Ree":
            ax.set_ylabel(r"$R_{ee}$ (Å)", fontsize=AXIS_LABEL_FONTSIZE)
            #ax.set_ylim(0, 80)
            ax.set_ylim(0, 10)
        elif metric == "SASA":
            ax.set_ylabel(metric + " (nm²)", fontsize=AXIS_LABEL_FONTSIZE)
            #ax.set_ylim(0, 3500)
            ax.set_ylim(0, 150)
        else:
            ax.set_ylabel("Asphericity", fontsize=AXIS_LABEL_FONTSIZE)
            ax.set_ylim(0, 0.6)

        ax.tick_params(axis="both", labelsize=TICK_LABEL_FONTSIZE)
        ax.grid(False)
        #ax.legend()

    plt.tight_layout()
    plt.savefig(f"{output_fig_name}_{x_axis}.png", dpi=300)

# Save matched UniProt IDs to a text file
with open(output_matches, "w") as file:
    for uniprot_id in sorted(set(matched_ids)):  # Ensure uniqueness and sorted order
        file.write(uniprot_id + "\n")

print(f"Saved {len(set(matched_ids))} matched UniProt IDs to 'matched_uniprot_ids.txt'.")
