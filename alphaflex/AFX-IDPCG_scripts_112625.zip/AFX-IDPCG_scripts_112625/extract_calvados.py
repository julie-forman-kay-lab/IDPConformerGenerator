import os
import mdtraj as md
from glob import glob
from tqdm import tqdm
from concurrent.futures import ProcessPoolExecutor
import subprocess


def reconstruct_uniprot_id(path_parts):
    """Reconstruct UniProt ID from folder structure"""
    # For 10-character IDs: XX/XX/XX/XXXX -> XXXXXXXXXX
    if len(path_parts) == 4:
        return ''.join(path_parts)
    # For shorter IDs: XX/XX/XX -> XXXXXX  
    elif len(path_parts) == 3:
        return ''.join(path_parts)
    else:
        return None

def process_trajectory(traj_folder):
    """Process a single trajectory folder"""
    top_file = os.path.join(traj_folder, "top.pdb")
    traj_file = os.path.join(traj_folder, "traj.xtc")
    
    if not (os.path.exists(top_file) and os.path.exists(traj_file)):
        return None
    
    try:
        # Load trajectory
        traj = md.load(traj_file, top=top_file)
        
        # Extract every 10th frame (frames 0, 10, 20, ..., 990)
        frames = traj[::10]  # This gives us 100 frames from 1000
        
        # Reconstruct UniProt ID and range from path
        path_parts = traj_folder.replace(base_folder, '').strip('/').split('/')
        range_part = path_parts[-1]  # X-X part
        id_parts = path_parts[:-1]   # UniProt ID parts
        
        uniprot_id = reconstruct_uniprot_id(id_parts)
        if not uniprot_id:
            return f"Failed to reconstruct ID from {traj_folder}"
        
        # Create output filename
        output_filename = f"{uniprot_id}_{range_part}_n100.pdb"
        output_path = os.path.join(output_folder, output_filename)
        
        # Save as multi-model PDB using pdb_mkensemble
        temp_folder = f"temp_{uniprot_id}_{range_part}"
        os.makedirs(temp_folder, exist_ok=True)
        
        # Save individual frames
        for i, frame in enumerate(frames):
            frame_path = os.path.join(temp_folder, f"frame_{i:03d}.pdb")
            frame[0].save_pdb(frame_path)
        
        # Use pdb_mkensemble to combine frames
        pdb_files = sorted(glob(os.path.join(temp_folder, "*.pdb")))
        with open(output_path, "w") as outf:
            subprocess.run(["pdb_mkensemble"] + pdb_files, stdout=outf, check=True)
        
        # Cleanup temp files
        for f in pdb_files:
            os.remove(f)
        os.rmdir(temp_folder)
        
        return f"Processed: {output_filename}"
        
    except Exception as e:
        return f"Error processing {traj_folder}: {str(e)}"

# Configuration
base_folder = "../IDROME/IDRome_v4"  # Adjust to your path
output_folder = "../IDROME/extracted_idrome_ensembles"
os.makedirs(output_folder, exist_ok=True)

# Find all trajectory folders (containing both top.pdb and traj.xtc)
traj_folders = []
for root, dirs, files in os.walk(base_folder):
    if "top.pdb" in files and "traj.xtc" in files:
        traj_folders.append(root)

print(f"Found {len(traj_folders)} trajectory folders")

# Process trajectories
if __name__ == "__main__":
    n_workers = 32  
    results = []
    with ProcessPoolExecutor(max_workers=n_workers) as exe:
        for result in tqdm(exe.map(process_trajectory, traj_folders), total=len(traj_folders), desc="Processing trajectories"):
            if result:
                results.append(result)
                if "Error" in result:
                    print(result)

print(f"\nProcessed {len(results)} trajectories")
print("Sample results:")
for r in results[:5]:
    print(f"  {r}")
